"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { supabaseBrowser } from "@/lib/supabase/browser";

export default function SignupPage() {
  const router = useRouter();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [info, setInfo] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null); setInfo(null);
    start(async () => {
      const sb = supabaseBrowser();
      const { data, error } = await sb.auth.signUp({
        email,
        password,
        options: {
          data: { full_name: fullName },
          emailRedirectTo: typeof window !== "undefined" ? `${window.location.origin}/` : undefined,
        },
      });
      if (error) { setError(error.message); return; }
      if (data.session) {
        router.replace("/");
        router.refresh();
      } else {
        setInfo("Check your inbox to confirm your email, then sign in.");
      }
    });
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <form onSubmit={submit} className="card w-full max-w-sm p-7">
        <div className="flex items-center gap-2 mb-6">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M3 11 L12 3 L21 11 V20 H3 Z" stroke="currentColor" strokeWidth="1.6" />
            <path d="M9 20 V13 H15 V20" stroke="currentColor" strokeWidth="1.6" />
          </svg>
          <span className="font-semibold tracking-tight text-lg">Domo</span>
        </div>
        <h1 className="text-xl font-semibold mb-1">Create account</h1>
        <p className="text-sm text-muted mb-5">Your workspace is created automatically.</p>

        <label className="label">Full name</label>
        <input className="input mb-3" required value={fullName}
               onChange={(e) => setFullName(e.target.value)} />

        <label className="label">Email</label>
        <input className="input mb-3" type="email" required value={email}
               onChange={(e) => setEmail(e.target.value)} autoComplete="email" />

        <label className="label">Password</label>
        <input className="input mb-4" type="password" required minLength={8} value={password}
               onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" />

        {error && <div className="text-sm text-[color:var(--danger)] mb-3">{error}</div>}
        {info && <div className="text-sm text-muted mb-3">{info}</div>}

        <button className="btn btn-primary w-full justify-center" disabled={pending}>
          {pending ? "Creating…" : "Create account"}
        </button>
        <p className="text-sm text-muted mt-4 text-center">
          Already have one? <Link className="text-ink underline" href="/login">Sign in</Link>
        </p>
      </form>
    </div>
  );
}
