"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { supabaseServer } from "@/lib/supabase/server";
import { requireWorkspace } from "@/lib/auth";

/* ============================================================
   DOCUMENTS
   ============================================================ */
const DocumentMetaSchema = z.object({
  property_id: z.string().uuid(),
  unit_id: z.string().uuid().optional().nullable(),
  tenant_id: z.string().uuid().optional().nullable(),
  contract_id: z.string().uuid().optional().nullable(),
  document_type: z.enum([
    "contract","invoice","bank statement","email","photo","drawing",
    "tax document","valuation document","renovation document","other",
  ]),
  name: z.string().min(1),
  original_name: z.string().optional().nullable(),
  storage_path: z.string().min(1),
  mime_type: z.string().optional().nullable(),
  size_bytes: z.coerce.number().optional().nullable(),
  document_date: z.string().optional().nullable(),
  amount: z.coerce.number().optional().nullable(),
  supplier: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
});

function fdToObj(fd: FormData) {
  const o: Record<string, FormDataEntryValue> = {};
  fd.forEach((v, k) => { if (v !== "") o[k] = v; });
  return o;
}

/** Insert a document row AFTER the file was uploaded client-side to storage. */
export async function createDocument(fd: FormData) {
  const ctx = await requireWorkspace();
  const data = DocumentMetaSchema.parse(fdToObj(fd));
  const sb = supabaseServer();
  const { error } = await sb.from("documents").insert({
    ...data, workspace_id: ctx.workspaceId, created_by: ctx.userId,
  });
  if (error) throw new Error(error.message);
  revalidatePath(`/portfolio/${data.property_id}`);
}

export async function deleteDocument(id: string, propertyId: string, storagePath: string) {
  await requireWorkspace();
  const sb = supabaseServer();
  await sb.storage.from("documents").remove([storagePath]);
  const { error } = await sb.from("documents").delete().eq("id", id);
  if (error) throw new Error(error.message);
  revalidatePath(`/portfolio/${propertyId}`);
}

/** Re-link a document to a different property — requires confirmation in UI. */
const RelinkSchema = z.object({
  id: z.string().uuid(),
  property_id: z.string().uuid(),
});
export async function relinkDocument(fd: FormData) {
  await requireWorkspace();
  const data = RelinkSchema.parse(fdToObj(fd));
  const sb = supabaseServer();
  const { error } = await sb.from("documents")
    .update({ property_id: data.property_id })
    .eq("id", data.id);
  if (error) throw new Error(error.message);
  revalidatePath(`/portfolio/${data.property_id}`);
}

/** Returns a short-lived signed URL for downloading/viewing. */
export async function signedDocumentUrl(storagePath: string): Promise<string> {
  await requireWorkspace();
  const sb = supabaseServer();
  const { data, error } = await sb.storage
    .from("documents")
    .createSignedUrl(storagePath, 60 * 10); // 10 min
  if (error || !data) throw new Error(error?.message ?? "Could not sign");
  return data.signedUrl;
}

/* ============================================================
   AI INBOX
   ============================================================ */
const InboxReviewSchema = z.object({
  id: z.string().uuid(),
  suggested_property_id: z.string().uuid().optional().nullable(),
  suggested_unit_id: z.string().uuid().optional().nullable(),
  suggested_document_type: z.string().optional().nullable(),
  suggested_document_date: z.string().optional().nullable(),
  suggested_amount: z.coerce.number().optional().nullable(),
  suggested_category: z.string().optional().nullable(),
  suggested_supplier: z.string().optional().nullable(),
  suggested_clean_name: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
});

/** Save edits to an inbox item without approving. */
export async function saveInboxReview(fd: FormData) {
  await requireWorkspace();
  const data = InboxReviewSchema.parse(fdToObj(fd));
  const sb = supabaseServer();
  const { error } = await sb.from("inbox_items").update({
    ...data, ai_status: "reviewed",
  }).eq("id", data.id);
  if (error) throw new Error(error.message);
  revalidatePath("/inbox");
}

/**
 * Approve an inbox item:
 *  1. Move the file under property_id/ in storage with the clean name
 *  2. Create a documents row
 *  3. Optionally create an expense row if amount + category set
 *  4. Mark the inbox row approved + link resulting document
 */
export async function approveInboxItem(fd: FormData) {
  const ctx = await requireWorkspace();
  const data = InboxReviewSchema.parse(fdToObj(fd));
  if (!data.suggested_property_id) throw new Error("Property is required to approve.");
  if (!data.suggested_document_type) throw new Error("Document type is required.");

  const sb = supabaseServer();

  const { data: item, error: e0 } = await sb.from("inbox_items")
    .select("storage_path, original_filename, mime_type, size_bytes")
    .eq("id", data.id).single();
  if (e0 || !item) throw new Error(e0?.message ?? "Inbox item not found");

  // Build clean storage path: <workspace>/<property>/<docId-ish or date>_<clean>.ext
  const ext = (item.original_filename.match(/\.[^.]+$/)?.[0] ?? "").toLowerCase();
  const cleanBase = (data.suggested_clean_name?.replace(/\.[^.]+$/, "") ?? item.original_filename.replace(/\.[^.]+$/, ""))
    .replace(/[^a-zA-Z0-9._-]+/g, "_");
  const cleanName = `${cleanBase}${ext}`;
  const targetPath = `${ctx.workspaceId}/${data.suggested_property_id}/${Date.now()}_${cleanName}`;

  // Move via copy + remove (storage.move() also works but copy+remove is more forgiving)
  const { error: eMove } = await sb.storage.from("documents").move(item.storage_path, targetPath);
  if (eMove) throw new Error(`Storage move failed: ${eMove.message}`);

  // Insert document row
  const { data: doc, error: eDoc } = await sb.from("documents").insert({
    workspace_id: ctx.workspaceId,
    property_id: data.suggested_property_id,
    unit_id: data.suggested_unit_id ?? null,
    document_type: data.suggested_document_type,
    name: cleanName,
    original_name: item.original_filename,
    storage_path: targetPath,
    mime_type: item.mime_type,
    size_bytes: item.size_bytes,
    document_date: data.suggested_document_date ?? null,
    amount: data.suggested_amount ?? null,
    supplier: data.suggested_supplier ?? null,
    notes: data.notes ?? null,
    created_by: ctx.userId,
  }).select("id").single();
  if (eDoc || !doc) throw new Error(eDoc?.message ?? "Could not insert document");

  // If this looks like an expense (invoice + amount + category), create the expense too.
  if (data.suggested_amount && data.suggested_category &&
      ["maintenance","renovation","local tax","mortgage","insurance","utilities","legal","accountant","bank","management","other"]
        .includes(data.suggested_category)) {
    await sb.from("expenses").insert({
      workspace_id: ctx.workspaceId,
      property_id: data.suggested_property_id,
      unit_id: data.suggested_unit_id ?? null,
      document_id: doc.id,
      date: data.suggested_document_date ?? new Date().toISOString().slice(0, 10),
      category: data.suggested_category,
      supplier: data.suggested_supplier ?? null,
      amount: data.suggested_amount,
      notes: data.notes ?? null,
      created_by: ctx.userId,
    });
  }

  const { error: eUp } = await sb.from("inbox_items").update({
    ai_status: "approved",
    resulting_document_id: doc.id,
  }).eq("id", data.id);
  if (eUp) throw new Error(eUp.message);

  revalidatePath("/inbox");
  revalidatePath(`/portfolio/${data.suggested_property_id}`);
}

export async function deleteInboxItem(id: string, storagePath: string) {
  await requireWorkspace();
  const sb = supabaseServer();
  await sb.storage.from("documents").remove([storagePath]);
  const { error } = await sb.from("inbox_items").delete().eq("id", id);
  if (error) throw new Error(error.message);
  revalidatePath("/inbox");
}
