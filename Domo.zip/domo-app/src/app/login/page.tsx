"use client";

import { useState, useTransition } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { supabaseBrowser } from "@/lib/supabase/browser";

export default function LoginPage() {
  const router = useRouter();
  const next = useSearchParams().get("next") || "/";
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    start(async () => {
      const sb = supabaseBrowser();
      const { error } = await sb.auth.signInWithPassword({ email, password });
      if (error) { setError(error.message); return; }
      router.replace(next);
      router.refresh();
    });
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <form onSubmit={submit} className="card w-full max-w-sm p-7">
        <div className="flex items-center gap-2 mb-6">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M3 11 L12 3 L21 11 V20 H3 Z" stroke="currentColor" strokeWidth="1.6" />
            <path d="M9 20 V13 H15 V20" stroke="currentColor" strokeWidth="1.6" />
          </svg>
          <span className="font-semibold tracking-tight text-lg">Domo</span>
        </div>
        <h1 className="text-xl font-semibold mb-1">Sign in</h1>
        <p className="text-sm text-muted mb-5">to your property cockpit</p>

        <label className="label">Email</label>
        <input className="input mb-3" type="email" required value={email}
               onChange={(e) => setEmail(e.target.value)} autoComplete="email" />

        <label className="label">Password</label>
        <input className="input mb-4" type="password" required value={password}
               onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" />

        {error && <div className="text-sm text-[color:var(--danger)] mb-3">{error}</div>}

        <button className="btn btn-primary w-full justify-center" disabled={pending}>
          {pending ? "Signing in…" : "Sign in"}
        </button>
        <p className="text-sm text-muted mt-4 text-center">
          New here? <Link className="text-ink underline" href="/signup">Create account</Link>
        </p>
      </form>
    </div>
  );
}
