import Link from "next/link";
import { redirect } from "next/navigation";
import { signOut } from "@/app/actions/auth";
import { requireWorkspace } from "@/lib/auth";
import { supabaseServer } from "@/lib/supabase/server";

const NAV = [
  { href: "/",           label: "Cockpit"       },
  { href: "/portfolio",  label: "Portfolio"     },
  { href: "/rent",       label: "Huurcontrole"  },
  { href: "/inbox",      label: "AI Inbox"      },
  { href: "/reports",    label: "Reports"       },
  { href: "/settings",   label: "Settings"      },
];

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const ctx = await requireWorkspace();
  const sb = supabaseServer();
  const { data: ws } = await sb.from("workspaces").select("name").eq("id", ctx.workspaceId).single();

  return (
    <div className="min-h-screen flex">
      <aside className="w-[220px] border-r border-line bg-surface flex flex-col">
        <div className="px-5 py-5 border-b border-line">
          <div className="flex items-center gap-2">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <path d="M3 11 L12 3 L21 11 V20 H3 Z" stroke="currentColor" strokeWidth="1.6" />
              <path d="M9 20 V13 H15 V20" stroke="currentColor" strokeWidth="1.6" />
            </svg>
            <span className="font-semibold tracking-tight">Domo</span>
          </div>
          <div className="text-[11px] text-muted mt-2 truncate">{ws?.name ?? "Workspace"}</div>
        </div>
        <nav className="px-2 py-3 flex-1">
          {NAV.map(n => (
            <Link key={n.href} href={n.href}
              className="block px-3 py-1.5 rounded text-[13px] text-ink hover:bg-[oklch(96%_0.005_95)]">
              {n.label}
            </Link>
          ))}
        </nav>
        <form action={async () => { "use server"; await signOut(); }}
              className="px-4 py-3 border-t border-line">
          <div className="text-[11px] text-muted truncate mb-2">{ctx.email}</div>
          <button className="btn w-full justify-center" type="submit">Sign out</button>
        </form>
      </aside>
      <main className="flex-1 min-w-0">{children}</main>
    </div>
  );
}
