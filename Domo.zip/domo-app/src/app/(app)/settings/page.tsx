import { requireWorkspace } from "@/lib/auth";
import { supabaseServer } from "@/lib/supabase/server";

const EXP_CATS = ["maintenance","renovation","local tax","mortgage","insurance","utilities","legal","accountant","bank","management","other"];
const DOC_CATS = ["contract","invoice","bank statement","email","photo","drawing","tax document","valuation document","renovation document","other"];

export default async function SettingsPage() {
  const ctx = await requireWorkspace();
  const sb = supabaseServer();
  const { data: ws } = await sb.from("workspaces").select("name, created_at").eq("id", ctx.workspaceId).single();

  return (
    <div className="px-10 py-8 max-w-4xl">
      <h1 className="text-[22px] font-semibold tracking-tight mb-1">Settings</h1>
      <p className="text-sm text-muted mb-6">Workspace and category configuration.</p>

      <section className="card p-5 mb-5">
        <h2 className="font-semibold mb-3">Workspace</h2>
        <Row label="Name" value={ws?.name ?? "—"} />
        <Row label="Created" value={ws?.created_at ? new Date(ws.created_at).toLocaleDateString("nl-NL") : "—"} />
        <Row label="Your email" value={ctx.email ?? "—"} />
        <Row label="Workspace ID" value={ctx.workspaceId} mono />
      </section>

      <section className="card p-5 mb-5">
        <h2 className="font-semibold mb-3">Expense categories</h2>
        <p className="text-xs text-muted mb-2">
          In V1 these are fixed. Edit by changing the CHECK constraint in the SQL migration.
        </p>
        <div className="flex flex-wrap gap-1.5">
          {EXP_CATS.map(c => <span key={c} className="px-2 py-1 rounded text-xs bg-[oklch(96%_0_0)] text-ink">{c}</span>)}
        </div>
      </section>

      <section className="card p-5 mb-5">
        <h2 className="font-semibold mb-3">Document categories</h2>
        <div className="flex flex-wrap gap-1.5">
          {DOC_CATS.map(c => <span key={c} className="px-2 py-1 rounded text-xs bg-[oklch(96%_0_0)] text-ink">{c}</span>)}
        </div>
      </section>

      <section className="card p-5">
        <h2 className="font-semibold mb-2">Export / Backup</h2>
        <p className="text-sm text-muted mb-3">
          CSV export is available from the Reports page. Full Postgres backup is provided by Supabase.
        </p>
      </section>
    </div>
  );
}

function Row({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex items-center justify-between py-1.5 border-b border-line last:border-0">
      <span className="text-sm text-muted">{label}</span>
      <span className={`text-sm ${mono ? "num" : ""}`}>{value}</span>
    </div>
  );
}
