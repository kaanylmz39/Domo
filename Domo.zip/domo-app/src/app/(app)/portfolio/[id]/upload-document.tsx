"use client";

import { useState, useTransition } from "react";
import { Modal } from "@/components/ui";
import { supabaseBrowser } from "@/lib/supabase/browser";
import { createDocument } from "@/app/actions/documents";

const TYPES = ["contract","invoice","bank statement","email","photo","drawing","tax document","valuation document","renovation document","other"];

export function UploadDocumentButton({
  propertyId, units, contracts,
}: { propertyId: string; units: any[]; contracts: any[] }) {
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  return (
    <Modal title="Upload document" trigger={<button className="btn btn-primary">+ Upload</button>}>
      {(close) => (
        <form
          className="space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            const form = e.currentTarget;
            if (!file) { setError("Please choose a file."); return; }
            start(async () => {
              setError(null);
              const sb = supabaseBrowser();
              const { data: { user } } = await sb.auth.getUser();
              if (!user) { setError("Not signed in"); return; }
              const { data: prof } = await sb.from("user_profiles").select("workspace_id").eq("user_id", user.id).single();
              if (!prof) { setError("No workspace"); return; }
              const path = `${prof.workspace_id}/${propertyId}/${Date.now()}_${file.name.replace(/[^a-zA-Z0-9._-]+/g, "_")}`;
              const { error: upErr } = await sb.storage.from("documents").upload(path, file, {
                contentType: file.type, upsert: false,
              });
              if (upErr) { setError(upErr.message); return; }
              const fd = new FormData(form);
              fd.set("storage_path", path);
              fd.set("name", String(fd.get("name") || file.name));
              fd.set("original_name", file.name);
              fd.set("mime_type", file.type);
              fd.set("size_bytes", String(file.size));
              fd.set("property_id", propertyId);
              await createDocument(fd);
              close();
            });
          }}
        >
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <label className="label">File</label>
              <input type="file" required onChange={(e) => setFile(e.target.files?.[0] ?? null)} className="input" />
            </div>
            <div><label className="label">Display name</label>
              <input name="name" className="input" placeholder={file?.name ?? "auto"} /></div>
            <div><label className="label">Type</label>
              <select name="document_type" className="input">{TYPES.map(t => <option key={t}>{t}</option>)}</select></div>
            <div><label className="label">Document date</label><input name="document_date" type="date" className="input" /></div>
            <div><label className="label">Amount</label><input name="amount" type="number" step="0.01" className="input" /></div>
            <div><label className="label">Supplier</label><input name="supplier" className="input" /></div>
            <div><label className="label">Unit (optional)</label>
              <select name="unit_id" className="input"><option value="">—</option>
                {units.map(u => <option key={u.id} value={u.id}>{u.label}</option>)}
              </select></div>
            <div className="col-span-2"><label className="label">Contract (optional)</label>
              <select name="contract_id" className="input"><option value="">—</option>
                {contracts.map(c => <option key={c.id} value={c.id}>{c.tenants?.name ?? "Contract"} — {c.start_date}</option>)}
              </select></div>
            <div className="col-span-2"><label className="label">Notes</label><textarea name="notes" rows={2} className="input" /></div>
          </div>
          {error && <div className="text-sm text-[color:var(--danger)]">{error}</div>}
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" className="btn" onClick={close}>Cancel</button>
            <button type="submit" className="btn btn-primary" disabled={pending}>
              {pending ? "Uploading…" : "Upload"}
            </button>
          </div>
        </form>
      )}
    </Modal>
  );
}
