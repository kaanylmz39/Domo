import { supabaseServer } from "@/lib/supabase/server";
import { redirect } from "next/navigation";

/** Returns { userId, workspaceId } or redirects to /login. */
export async function requireWorkspace() {
  const sb = supabaseServer();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) redirect("/login");
  const { data: profile } = await sb.from("user_profiles")
    .select("workspace_id, full_name, email")
    .eq("user_id", user.id)
    .single();
  if (!profile) {
    // Profile row should be created by the on_auth_user_created trigger.
    // If missing (older account, etc), bail to login.
    redirect("/login");
  }
  return {
    userId: user.id,
    email: user.email ?? null,
    workspaceId: profile.workspace_id as string,
    fullName: (profile.full_name as string | null) ?? null,
  };
}
