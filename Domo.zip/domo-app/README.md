# Domo — Real estate cockpit (Next.js + Supabase MVP)

A small online-first real estate data management app for tiny portfolios.
Property is the central anchor; tenants, contracts, rent, expenses, documents,
deposits, developments and valuations all hang off it.

This is V1 — clean foundation, no over-engineering. Designed so AI document
processing, advanced reports, and team roles can be layered in later without
restructuring.

---

## Tech

- **Next.js 14** (app router) + React + TypeScript
- **Tailwind CSS**
- **Supabase** — Postgres, Auth, Storage
- **Vercel** — deployment target

No Prisma. Supabase JS client + raw SQL migrations keep auth + Row Level
Security simple and obvious.

---

## Architecture overview

```
src/
  middleware.ts                    auth gate (redirects unauth'd to /login)
  app/
    login/, signup/                public auth pages
    auth/callback/route.ts         OAuth/magic-link callback
    (app)/                         protected route group
      layout.tsx                   sidebar shell, signOut
      page.tsx                     Cockpit
      portfolio/                   Portfolio list + /[id] property dossier
      rent/                        Huurcontrole monthly checklist
      inbox/                       AI Inbox review/approve
      reports/                     Yearly totals + CSV export
      settings/                    Workspace + category info
    api/export/yearly/route.ts     CSV stream
    actions/                       'use server' actions (CRUD)
  lib/
    supabase/{browser,server,middleware}.ts
    auth.ts                        requireWorkspace() — gates protected pages
    format.ts                      money/date helpers
    types.ts                       hand-rolled DB row types
  components/
    ConfirmButton.tsx              wraps destructive actions in a confirm modal
    ui.tsx                         Modal, Badge
supabase/
  migrations/0001_init.sql         schema, RLS, storage policies, RPC
```

### Workspace model (V1)

- On signup, a Postgres trigger (`handle_new_user`) creates one workspace and
  one `user_profiles` row linking the user to that workspace.
- A SQL helper `current_workspace_id()` looks up that row by `auth.uid()`.
- Every domain table has `workspace_id`. Every RLS policy boils down to
  `workspace_id = current_workspace_id()` — so users only ever see their own
  data, enforced at the database.
- Multi-user workspaces and roles can be added later by changing
  `current_workspace_id()` and adding a join table; no app code changes needed.

### Property is the anchor

All domain rows carry `property_id` directly or transitively (through
contract/unit). Documents are categorized by `document_type` and rendered in
the property dossier under fixed buckets (Contracts, Invoices, …).

### Rent control flow

1. Active contracts have `monthly_rent` + `due_day`.
2. `generate_rent_for_month(p_month date)` (Postgres function) idempotently
   inserts one `rent_expected_payments` row per active contract per month.
3. The Huurcontrole page calls that function on every visit, then lists rows.
4. User clicks "Log" → server action `markRentPayment` updates status and
   syncs an `income` row (rent only — deposits are NEVER income).
5. Cockpit + Reports aggregate from `income` and `expenses`.

### AI Inbox flow (V1 — no real AI yet)

1. Upload writes to `documents` bucket at `<workspace_id>/_inbox/...`.
2. Row appears in `inbox_items` with `ai_status='pending'`.
3. User reviews/edits property, unit, type, date, amount, category, clean
   filename.
4. "Approve & file" requires confirmation. On approve:
   - file is moved to `<workspace_id>/<property_id>/<timestamped clean name>`
   - a `documents` row is created
   - if amount + category set, an `expenses` row is auto-created
   - inbox item is marked approved + linked to the document
5. Schema fields are all named so a real AI step can fill `suggested_*` columns
   later — UI doesn't change.

### Destructive actions

Every destructive or major action goes through `<ConfirmButton>`, which
renders a centered modal with Cancel / [Action] buttons:
delete property, unit, contract, document, expense; approve inbox item; relink
a document's property.

### Storage

One private bucket `documents`. RLS policies allow access only to objects
whose first path segment matches the caller's `current_workspace_id()`. The
app never bypasses this; all uploads use the user's anon session.

Document downloads use short-lived (10-min) signed URLs created server-side.

---

## Database schema

See `supabase/migrations/0001_init.sql`. Tables (all workspace-scoped, all
with `id, workspace_id, created_at, updated_at`):

`workspaces, user_profiles, properties, units, tenants, contracts, documents,
expenses, portfolio_expenses, income, deposits, rent_expected_payments,
developments, development_documents, valuations, inbox_items`.

---

## Main user flows

1. **Sign up** → workspace + profile created via DB trigger → land on Cockpit.
2. **Add property** → enter from `/portfolio` → property dossier opens.
3. **Add units / contracts / documents** from the dossier tabs.
4. **Each month**: visit `/rent`, log payments. Rent rows for the month are
   auto-generated by the DB function.
5. **Files arrive**: upload to `/inbox`, review, approve → filed under
   property.
6. **Year-end**: visit `/reports`, export CSV.

---

## Local development

### Prerequisites

- Node 20+
- A Supabase project (https://supabase.com)

### Setup

```bash
cd domo-app
npm install
cp .env.example .env.local
# edit .env.local with your Supabase URL + anon key
```

In the Supabase dashboard:

1. **SQL Editor** → paste contents of `supabase/migrations/0001_init.sql` → Run.
2. **Authentication → Email** → confirm signups enabled (or disable for dev).
3. **Authentication → URL Configuration** → add `http://localhost:3000/auth/callback`
   to Redirect URLs.
4. **Storage** — the migration creates the `documents` bucket as private with
   the right RLS policies. Verify it exists.

### Run

```bash
npm run dev
```

Open http://localhost:3000 → you'll be redirected to /login. Create an
account; on confirmation you'll land in your empty workspace.

---

## Deployment

### Vercel

1. Push the `domo-app/` folder to GitHub.
2. In Vercel: import repo, set Root Directory to `domo-app`.
3. Add Environment Variables:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `NEXT_PUBLIC_SITE_URL` (your production URL)
4. Deploy.
5. In Supabase Auth settings, add `https://<your-vercel-domain>/auth/callback`
   to the redirect URL list.

### Required environment variables

| Variable | Where | Notes |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | client + server | from Supabase project settings |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | client + server | anon key — safe to expose |
| `NEXT_PUBLIC_SITE_URL` | client | e.g. `https://domo.example.com` |
| `SUPABASE_SERVICE_ROLE_KEY` | optional, server-only | not used in V1, keep for later admin tasks |

---

## Security checklist

- ✅ Supabase Auth (email + password)
- ✅ Protected routes via middleware
- ✅ RLS on every workspace-scoped table — verified via SQL policies
- ✅ Storage RLS scoped by workspace prefix
- ✅ All mutations go through `'use server'` actions that call
  `requireWorkspace()` and pass user context
- ✅ Zod validation on every form payload
- ✅ Confirmation modals on every destructive action
- ✅ Signed URLs (10 min) for document downloads
- ✅ Secrets only in env vars, never hardcoded

---

## What V1 deliberately does NOT include

(Per the spec — easy to add later because the schema already names the fields):

- Real AI classification of inbox items
- Tenant portal / online rent collection
- Bank or payment integrations
- Multi-user workspaces, roles
- PDF reports
- Mobile app
- Appliance/asset tracking on properties

---

## Where to add things later

| Want to add | Where |
|---|---|
| Real AI for inbox | `inbox_items.suggested_*` fields already exist — populate from a server action / edge function |
| Team members | `user_profiles.workspace_id` is already the join — add a row per user |
| Roles | New column on `user_profiles`, gate server actions on it |
| New expense category | Update CHECK in migration + arrays in `actions/domain.ts` and `settings/page.tsx` |
| New document type | Same — update CHECK + `DOC_TYPES` constant |
| Custom report | New page under `(app)/reports/` — read from existing tables |
