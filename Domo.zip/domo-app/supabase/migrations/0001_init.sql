-- Domo — Supabase schema, RLS, and storage policies
-- ============================================================
-- Run in Supabase SQL Editor (or via `supabase db push` migrations).
-- Idempotent: safe to re-run.

-- ----- Extensions -----
create extension if not exists "pgcrypto";

-- ============================================================
-- 1. WORKSPACES & USER PROFILES
-- ============================================================
create table if not exists public.workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.user_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  full_name text,
  email text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_user_profiles_workspace on public.user_profiles(workspace_id);

-- Helper: workspace_id of currently authenticated user.
create or replace function public.current_workspace_id()
returns uuid
language sql stable security definer
set search_path = public
as $$
  select workspace_id from public.user_profiles where user_id = auth.uid()
$$;

-- ============================================================
-- 2. CORE DOMAIN TABLES
-- ============================================================

-- ----- Properties -----
create table if not exists public.properties (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  created_by uuid references auth.users(id) on delete set null,
  address text not null,
  city text not null,
  postcode text,
  property_type text not null default 'single' check (property_type in ('single','building')),
  status text not null default 'empty' check (status in ('rented','empty','renovating','partly','for-sale','unavailable')),
  purchase_price numeric(14,2),
  purchase_date date,
  woz_value numeric(14,2),
  bank text,
  last_renovation date,
  notes text,
  hue int default 90,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_properties_workspace on public.properties(workspace_id);

-- ----- Units -----
create table if not exists public.units (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  property_id uuid not null references public.properties(id) on delete cascade,
  label text not null,
  area_m2 numeric(8,2),
  bedrooms int,
  status text not null default 'empty' check (status in ('rented','empty','renovating','unavailable')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_units_workspace on public.units(workspace_id);
create index if not exists idx_units_property on public.units(property_id);

-- ----- Tenants -----
create table if not exists public.tenants (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  name text not null,
  email text,
  phone text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_tenants_workspace on public.tenants(workspace_id);

-- ----- Contracts -----
create table if not exists public.contracts (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  property_id uuid not null references public.properties(id) on delete cascade,
  unit_id uuid references public.units(id) on delete set null,
  tenant_id uuid references public.tenants(id) on delete set null,
  document_id uuid, -- forward ref; FK added after documents table
  start_date date not null,
  end_date date,
  monthly_rent numeric(12,2) not null,
  due_day int not null default 1 check (due_day between 1 and 31),
  deposit numeric(12,2) default 0,
  notice_period_months int default 1,
  next_increase_date date,
  notes text,
  status text not null default 'active' check (status in ('active','ended','upcoming')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_contracts_workspace on public.contracts(workspace_id);
create index if not exists idx_contracts_property on public.contracts(property_id);
create index if not exists idx_contracts_tenant on public.contracts(tenant_id);

-- ----- Documents -----
create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  property_id uuid not null references public.properties(id) on delete cascade,
  unit_id uuid references public.units(id) on delete set null,
  tenant_id uuid references public.tenants(id) on delete set null,
  contract_id uuid references public.contracts(id) on delete set null,
  document_type text not null default 'other' check (document_type in (
    'contract','invoice','bank statement','email','photo','drawing',
    'tax document','valuation document','renovation document','other'
  )),
  name text not null,                       -- final approved filename
  original_name text,                       -- as uploaded
  storage_path text not null,               -- supabase storage object key
  mime_type text,
  size_bytes bigint,
  document_date date,
  amount numeric(14,2),
  supplier text,
  notes text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_documents_workspace on public.documents(workspace_id);
create index if not exists idx_documents_property on public.documents(property_id);

-- Now we can add the deferred FK from contracts.document_id → documents.id
alter table public.contracts
  drop constraint if exists contracts_document_id_fkey,
  add constraint contracts_document_id_fkey
    foreign key (document_id) references public.documents(id) on delete set null;

-- ----- Expenses (property-level) -----
create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  property_id uuid references public.properties(id) on delete cascade,
  unit_id uuid references public.units(id) on delete set null,
  document_id uuid references public.documents(id) on delete set null,
  date date not null,
  category text not null check (category in (
    'maintenance','renovation','local tax','mortgage','insurance',
    'utilities','legal','accountant','bank','management','other'
  )),
  supplier text,
  amount numeric(14,2) not null,
  notes text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_expenses_workspace on public.expenses(workspace_id);
create index if not exists idx_expenses_property on public.expenses(property_id);

-- ----- Portfolio-level expenses (no property attribution) -----
create table if not exists public.portfolio_expenses (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  document_id uuid references public.documents(id) on delete set null,
  date date not null,
  category text not null check (category in (
    'accountant','bank','legal','management','other'
  )),
  supplier text,
  amount numeric(14,2) not null,
  notes text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_pexpenses_workspace on public.portfolio_expenses(workspace_id);

-- ----- Income (rent received & other) -----
create table if not exists public.income (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  property_id uuid references public.properties(id) on delete cascade,
  unit_id uuid references public.units(id) on delete set null,
  contract_id uuid references public.contracts(id) on delete set null,
  rent_expected_payment_id uuid,
  date date not null,
  category text not null default 'rent' check (category in ('rent','other')),
  amount numeric(14,2) not null,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_income_workspace on public.income(workspace_id);

-- ----- Deposits (held tenant funds, NOT income) -----
create table if not exists public.deposits (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  property_id uuid not null references public.properties(id) on delete cascade,
  unit_id uuid references public.units(id) on delete set null,
  tenant_id uuid references public.tenants(id) on delete set null,
  contract_id uuid references public.contracts(id) on delete set null,
  amount numeric(12,2) not null,
  received_date date not null,
  returned_date date,
  status text not null default 'active' check (status in ('active','partially returned','returned')),
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_deposits_workspace on public.deposits(workspace_id);

-- ----- Rent expected payments (monthly checklist rows generated from active contracts) -----
create table if not exists public.rent_expected_payments (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  contract_id uuid not null references public.contracts(id) on delete cascade,
  period_month date not null,                -- always first day of month
  due_date date not null,
  expected_amount numeric(12,2) not null,
  received_amount numeric(12,2),
  paid_status text not null default 'expected' check (paid_status in (
    'expected','paid','partial','unpaid','overdue'
  )),
  payment_date date,
  note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (contract_id, period_month)
);
create index if not exists idx_rep_workspace on public.rent_expected_payments(workspace_id);
create index if not exists idx_rep_month on public.rent_expected_payments(period_month);

alter table public.income
  drop constraint if exists income_rent_expected_payment_id_fkey,
  add constraint income_rent_expected_payment_id_fkey
    foreign key (rent_expected_payment_id) references public.rent_expected_payments(id) on delete set null;

-- ----- Developments (property changes/projects) -----
create table if not exists public.developments (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  property_id uuid not null references public.properties(id) on delete cascade,
  unit_id uuid references public.units(id) on delete set null,
  title text not null,
  dev_type text not null default 'maintenance',
  date date not null,
  description text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_developments_workspace on public.developments(workspace_id);

-- Many-to-many: development ↔ document
create table if not exists public.development_documents (
  development_id uuid not null references public.developments(id) on delete cascade,
  document_id uuid not null references public.documents(id) on delete cascade,
  primary key (development_id, document_id)
);

-- ----- Valuations -----
create table if not exists public.valuations (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  property_id uuid not null references public.properties(id) on delete cascade,
  document_id uuid references public.documents(id) on delete set null,
  date date not null,
  amount numeric(14,2) not null,
  valuation_type text not null check (valuation_type in (
    'WOZ','official appraisal','estimated market value','bank valuation','other'
  )),
  note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_valuations_workspace on public.valuations(workspace_id);

-- ----- Inbox items (uploaded files awaiting review/approval) -----
create table if not exists public.inbox_items (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  uploaded_by uuid references auth.users(id) on delete set null,
  original_filename text not null,
  storage_path text not null,
  mime_type text,
  size_bytes bigint,
  ai_status text not null default 'pending' check (ai_status in ('pending','detecting','reviewed','approved','rejected')),
  ai_confidence numeric(4,3),
  -- AI-suggested / user-edited fields:
  suggested_property_id uuid references public.properties(id) on delete set null,
  suggested_unit_id uuid references public.units(id) on delete set null,
  suggested_document_type text,
  suggested_document_date date,
  suggested_amount numeric(14,2),
  suggested_category text,
  suggested_supplier text,
  suggested_clean_name text,
  notes text,
  -- once approved, link the created document:
  resulting_document_id uuid references public.documents(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_inbox_workspace on public.inbox_items(workspace_id);

-- ============================================================
-- 3. UPDATED_AT TRIGGER
-- ============================================================
create or replace function public.tg_set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

do $$
declare t text;
begin
  for t in select unnest(array[
    'workspaces','user_profiles','properties','units','tenants','contracts',
    'documents','expenses','portfolio_expenses','income','deposits',
    'rent_expected_payments','developments','valuations','inbox_items'
  ]) loop
    execute format('drop trigger if exists trg_%I_updated on public.%I', t, t);
    execute format('create trigger trg_%I_updated before update on public.%I
                    for each row execute function public.tg_set_updated_at()', t, t);
  end loop;
end $$;

-- ============================================================
-- 4. WORKSPACE BOOTSTRAP — on new auth user, create workspace + profile
-- ============================================================
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer
set search_path = public
as $$
declare new_ws_id uuid;
begin
  insert into public.workspaces (name) values (coalesce(new.email, 'Workspace'))
    returning id into new_ws_id;
  insert into public.user_profiles (user_id, workspace_id, email, full_name)
    values (new.id, new_ws_id, new.email, coalesce(new.raw_user_meta_data->>'full_name', new.email));
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ============================================================
-- 5. ROW LEVEL SECURITY
-- ============================================================
-- All workspace-scoped tables share the same pattern: a row is visible
-- iff workspace_id = current_workspace_id().

do $$
declare t text;
begin
  for t in select unnest(array[
    'workspaces','user_profiles','properties','units','tenants','contracts',
    'documents','expenses','portfolio_expenses','income','deposits',
    'rent_expected_payments','developments','valuations','inbox_items',
    'development_documents'
  ]) loop
    execute format('alter table public.%I enable row level security', t);
  end loop;
end $$;

-- Workspaces themselves: user can see/update their own workspace only
drop policy if exists ws_select on public.workspaces;
create policy ws_select on public.workspaces for select
  using (id = public.current_workspace_id());
drop policy if exists ws_update on public.workspaces;
create policy ws_update on public.workspaces for update
  using (id = public.current_workspace_id());

-- user_profiles: a user can read/update only their own profile
drop policy if exists up_select on public.user_profiles;
create policy up_select on public.user_profiles for select using (user_id = auth.uid());
drop policy if exists up_update on public.user_profiles;
create policy up_update on public.user_profiles for update using (user_id = auth.uid());

-- Generic helper: emit all-CRUD policies for a workspace-scoped table
do $$
declare t text;
begin
  for t in select unnest(array[
    'properties','units','tenants','contracts','documents','expenses',
    'portfolio_expenses','income','deposits','rent_expected_payments',
    'developments','valuations','inbox_items'
  ]) loop
    execute format('drop policy if exists %I_sel on public.%I', t, t);
    execute format('create policy %I_sel on public.%I for select using (workspace_id = public.current_workspace_id())', t, t);
    execute format('drop policy if exists %I_ins on public.%I', t, t);
    execute format('create policy %I_ins on public.%I for insert with check (workspace_id = public.current_workspace_id())', t, t);
    execute format('drop policy if exists %I_upd on public.%I', t, t);
    execute format('create policy %I_upd on public.%I for update using (workspace_id = public.current_workspace_id()) with check (workspace_id = public.current_workspace_id())', t, t);
    execute format('drop policy if exists %I_del on public.%I', t, t);
    execute format('create policy %I_del on public.%I for delete using (workspace_id = public.current_workspace_id())', t, t);
  end loop;
end $$;

-- development_documents: through development_id → its workspace
drop policy if exists dd_sel on public.development_documents;
create policy dd_sel on public.development_documents for select using (
  exists (select 1 from public.developments d
          where d.id = development_id and d.workspace_id = public.current_workspace_id())
);
drop policy if exists dd_ins on public.development_documents;
create policy dd_ins on public.development_documents for insert with check (
  exists (select 1 from public.developments d
          where d.id = development_id and d.workspace_id = public.current_workspace_id())
);
drop policy if exists dd_del on public.development_documents;
create policy dd_del on public.development_documents for delete using (
  exists (select 1 from public.developments d
          where d.id = development_id and d.workspace_id = public.current_workspace_id())
);

-- ============================================================
-- 6. STORAGE — private bucket per workspace prefix
-- ============================================================
-- Run once in Supabase dashboard (Storage) or via:
insert into storage.buckets (id, name, public)
  values ('documents', 'documents', false)
  on conflict (id) do nothing;

-- Storage objects: filename convention is `<workspace_id>/<rest>`.
-- Policies restrict access to files whose first path segment matches the
-- caller's workspace_id.
drop policy if exists docs_select on storage.objects;
create policy docs_select on storage.objects for select
  using (
    bucket_id = 'documents'
    and (storage.foldername(name))[1] = public.current_workspace_id()::text
  );
drop policy if exists docs_insert on storage.objects;
create policy docs_insert on storage.objects for insert
  with check (
    bucket_id = 'documents'
    and (storage.foldername(name))[1] = public.current_workspace_id()::text
  );
drop policy if exists docs_update on storage.objects;
create policy docs_update on storage.objects for update
  using (
    bucket_id = 'documents'
    and (storage.foldername(name))[1] = public.current_workspace_id()::text
  );
drop policy if exists docs_delete on storage.objects;
create policy docs_delete on storage.objects for delete
  using (
    bucket_id = 'documents'
    and (storage.foldername(name))[1] = public.current_workspace_id()::text
  );

-- ============================================================
-- 7. RENT EXPECTED PAYMENT GENERATOR
-- ============================================================
-- Generates (or returns existing) checklist rows for a given month, for
-- every active contract in the caller's workspace. Idempotent.
create or replace function public.generate_rent_for_month(p_month date)
returns setof public.rent_expected_payments
language plpgsql security definer
set search_path = public
as $$
declare ws uuid;
begin
  ws := public.current_workspace_id();
  if ws is null then return; end if;

  insert into public.rent_expected_payments
    (workspace_id, contract_id, period_month, due_date, expected_amount, paid_status)
  select
    c.workspace_id,
    c.id,
    date_trunc('month', p_month)::date,
    (date_trunc('month', p_month)::date + (c.due_day - 1) * interval '1 day')::date,
    c.monthly_rent,
    case
      when (date_trunc('month', p_month)::date + (c.due_day - 1) * interval '1 day')::date < current_date
        then 'overdue'
      else 'expected'
    end
  from public.contracts c
  where c.workspace_id = ws
    and c.status = 'active'
    and c.start_date <= (date_trunc('month', p_month) + interval '1 month - 1 day')::date
    and (c.end_date is null or c.end_date >= date_trunc('month', p_month)::date)
  on conflict (contract_id, period_month) do nothing;

  return query
    select rep.* from public.rent_expected_payments rep
    where rep.workspace_id = ws
      and rep.period_month = date_trunc('month', p_month)::date
    order by rep.due_date;
end $$;

grant execute on function public.generate_rent_for_month(date) to authenticated;
grant execute on function public.current_workspace_id() to authenticated;
