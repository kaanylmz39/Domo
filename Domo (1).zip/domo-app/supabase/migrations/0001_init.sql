-- Domo — Single-tenant MVP schema (no auth)
-- ============================================================
-- This is the no-login version: one shared workspace, no RLS,
-- no user table, no auth trigger. Designed to deploy on Vercel
-- with a Supabase project using only the anon key.
--
-- Run in Supabase SQL Editor (or `supabase db push`). Idempotent.

create extension if not exists "pgcrypto";

-- ============================================================
-- WORKSPACES (single-row for V1)
-- ============================================================
create table if not exists public.workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ============================================================
-- CORE DOMAIN TABLES
-- ============================================================
create table if not exists public.properties (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  address text not null,
  city text not null,
  postcode text,
  property_type text not null default 'single' check (property_type in ('single','building')),
  status text not null default 'empty' check (status in ('rented','empty','renovating','partly','for-sale','unavailable')),
  purchase_price numeric(14,2),
  purchase_date date,
  woz_value numeric(14,2),
  bank text,
  last_renovation date,
  notes text,
  hue int default 90,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_properties_workspace on public.properties(workspace_id);

create table if not exists public.units (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  property_id uuid not null references public.properties(id) on delete cascade,
  label text not null,
  area_m2 numeric(8,2),
  bedrooms int,
  status text not null default 'empty' check (status in ('rented','empty','renovating','unavailable')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_units_property on public.units(property_id);

create table if not exists public.tenants (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  name text not null,
  email text,
  phone text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.contracts (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  property_id uuid not null references public.properties(id) on delete cascade,
  unit_id uuid references public.units(id) on delete set null,
  tenant_id uuid references public.tenants(id) on delete set null,
  document_id uuid,
  start_date date not null,
  end_date date,
  monthly_rent numeric(12,2) not null,
  due_day int not null default 1 check (due_day between 1 and 31),
  deposit numeric(12,2) default 0,
  notice_period_months int default 1,
  next_increase_date date,
  notes text,
  status text not null default 'active' check (status in ('active','ended','upcoming')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_contracts_property on public.contracts(property_id);

create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  property_id uuid not null references public.properties(id) on delete cascade,
  unit_id uuid references public.units(id) on delete set null,
  tenant_id uuid references public.tenants(id) on delete set null,
  contract_id uuid references public.contracts(id) on delete set null,
  document_type text not null default 'other' check (document_type in (
    'contract','invoice','bank statement','email','photo','drawing',
    'tax document','valuation document','renovation document','other'
  )),
  name text not null,
  original_name text,
  storage_path text not null,
  mime_type text,
  size_bytes bigint,
  document_date date,
  amount numeric(14,2),
  supplier text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_documents_property on public.documents(property_id);

alter table public.contracts
  drop constraint if exists contracts_document_id_fkey,
  add constraint contracts_document_id_fkey
    foreign key (document_id) references public.documents(id) on delete set null;

create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  property_id uuid references public.properties(id) on delete cascade,
  unit_id uuid references public.units(id) on delete set null,
  document_id uuid references public.documents(id) on delete set null,
  date date not null,
  category text not null check (category in (
    'maintenance','renovation','local tax','mortgage','insurance',
    'utilities','legal','accountant','bank','management','other'
  )),
  supplier text,
  amount numeric(14,2) not null,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_expenses_property on public.expenses(property_id);

create table if not exists public.portfolio_expenses (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  document_id uuid references public.documents(id) on delete set null,
  date date not null,
  category text not null check (category in ('accountant','bank','legal','management','other')),
  supplier text,
  amount numeric(14,2) not null,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.income (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  property_id uuid references public.properties(id) on delete cascade,
  unit_id uuid references public.units(id) on delete set null,
  contract_id uuid references public.contracts(id) on delete set null,
  rent_expected_payment_id uuid,
  date date not null,
  category text not null default 'rent' check (category in ('rent','other')),
  amount numeric(14,2) not null,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.deposits (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  property_id uuid not null references public.properties(id) on delete cascade,
  unit_id uuid references public.units(id) on delete set null,
  tenant_id uuid references public.tenants(id) on delete set null,
  contract_id uuid references public.contracts(id) on delete set null,
  amount numeric(12,2) not null,
  received_date date not null,
  returned_date date,
  status text not null default 'active' check (status in ('active','partially returned','returned')),
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.rent_expected_payments (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  contract_id uuid not null references public.contracts(id) on delete cascade,
  period_month date not null,
  due_date date not null,
  expected_amount numeric(12,2) not null,
  received_amount numeric(12,2),
  paid_status text not null default 'expected' check (paid_status in (
    'expected','paid','partial','unpaid','overdue'
  )),
  payment_date date,
  note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (contract_id, period_month)
);

alter table public.income
  drop constraint if exists income_rent_expected_payment_id_fkey,
  add constraint income_rent_expected_payment_id_fkey
    foreign key (rent_expected_payment_id) references public.rent_expected_payments(id) on delete set null;

create table if not exists public.developments (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  property_id uuid not null references public.properties(id) on delete cascade,
  unit_id uuid references public.units(id) on delete set null,
  title text not null,
  dev_type text not null default 'maintenance',
  date date not null,
  description text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.development_documents (
  development_id uuid not null references public.developments(id) on delete cascade,
  document_id uuid not null references public.documents(id) on delete cascade,
  primary key (development_id, document_id)
);

create table if not exists public.valuations (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  property_id uuid not null references public.properties(id) on delete cascade,
  document_id uuid references public.documents(id) on delete set null,
  date date not null,
  amount numeric(14,2) not null,
  valuation_type text not null check (valuation_type in (
    'WOZ','official appraisal','estimated market value','bank valuation','other'
  )),
  note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.inbox_items (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  original_filename text not null,
  storage_path text not null,
  mime_type text,
  size_bytes bigint,
  ai_status text not null default 'pending' check (ai_status in ('pending','detecting','reviewed','approved','rejected')),
  ai_confidence numeric(4,3),
  suggested_property_id uuid references public.properties(id) on delete set null,
  suggested_unit_id uuid references public.units(id) on delete set null,
  suggested_document_type text,
  suggested_document_date date,
  suggested_amount numeric(14,2),
  suggested_category text,
  suggested_supplier text,
  suggested_clean_name text,
  notes text,
  resulting_document_id uuid references public.documents(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ============================================================
-- UPDATED_AT TRIGGER
-- ============================================================
create or replace function public.tg_set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

do $$
declare t text;
begin
  for t in select unnest(array[
    'workspaces','properties','units','tenants','contracts',
    'documents','expenses','portfolio_expenses','income','deposits',
    'rent_expected_payments','developments','valuations','inbox_items'
  ]) loop
    execute format('drop trigger if exists trg_%I_updated on public.%I', t, t);
    execute format('create trigger trg_%I_updated before update on public.%I
                    for each row execute function public.tg_set_updated_at()', t, t);
  end loop;
end $$;

-- ============================================================
-- RLS: DISABLED for V1 (single-tenant, no auth)
-- ============================================================
-- The migration explicitly disables row level security on every table so the
-- anon key can read/write all data. This is intentional for the no-login MVP.
-- If you later add auth, re-enable RLS and add per-workspace policies.

do $$
declare t text;
begin
  for t in select unnest(array[
    'workspaces','properties','units','tenants','contracts',
    'documents','expenses','portfolio_expenses','income','deposits',
    'rent_expected_payments','developments','valuations','inbox_items',
    'development_documents'
  ]) loop
    execute format('alter table public.%I disable row level security', t);
  end loop;
end $$;

-- Make sure anon (and authenticated) can do everything on these tables.
do $$
declare t text;
begin
  for t in select unnest(array[
    'workspaces','properties','units','tenants','contracts',
    'documents','expenses','portfolio_expenses','income','deposits',
    'rent_expected_payments','developments','valuations','inbox_items',
    'development_documents'
  ]) loop
    execute format('grant all on public.%I to anon, authenticated', t);
  end loop;
end $$;

-- ============================================================
-- STORAGE — public-ish bucket (no auth, but file paths are unguessable)
-- ============================================================
insert into storage.buckets (id, name, public)
  values ('documents', 'documents', false)
  on conflict (id) do nothing;

-- Allow anon to read/write objects in the documents bucket.
drop policy if exists docs_select on storage.objects;
create policy docs_select on storage.objects for select
  using (bucket_id = 'documents');
drop policy if exists docs_insert on storage.objects;
create policy docs_insert on storage.objects for insert
  with check (bucket_id = 'documents');
drop policy if exists docs_update on storage.objects;
create policy docs_update on storage.objects for update
  using (bucket_id = 'documents');
drop policy if exists docs_delete on storage.objects;
create policy docs_delete on storage.objects for delete
  using (bucket_id = 'documents');

-- ============================================================
-- RENT EXPECTED PAYMENT GENERATOR
-- ============================================================
create or replace function public.generate_rent_for_month(p_month date, p_workspace uuid)
returns setof public.rent_expected_payments
language plpgsql
as $$
begin
  insert into public.rent_expected_payments
    (workspace_id, contract_id, period_month, due_date, expected_amount, paid_status)
  select
    c.workspace_id,
    c.id,
    date_trunc('month', p_month)::date,
    (date_trunc('month', p_month)::date + (c.due_day - 1) * interval '1 day')::date,
    c.monthly_rent,
    case
      when (date_trunc('month', p_month)::date + (c.due_day - 1) * interval '1 day')::date < current_date
        then 'overdue'
      else 'expected'
    end
  from public.contracts c
  where c.workspace_id = p_workspace
    and c.status = 'active'
    and c.start_date <= (date_trunc('month', p_month) + interval '1 month - 1 day')::date
    and (c.end_date is null or c.end_date >= date_trunc('month', p_month)::date)
  on conflict (contract_id, period_month) do nothing;

  return query
    select rep.* from public.rent_expected_payments rep
    where rep.workspace_id = p_workspace
      and rep.period_month = date_trunc('month', p_month)::date
    order by rep.due_date;
end $$;

grant execute on function public.generate_rent_for_month(date, uuid) to anon, authenticated;

-- ============================================================
-- SEED — one shared workspace
-- ============================================================
insert into public.workspaces (id, name)
select gen_random_uuid(), 'Personal portfolio'
where not exists (select 1 from public.workspaces);
