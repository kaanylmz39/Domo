import { createServerClient, type CookieOptions } from "@supabase/ssr";
import { cookies } from "next/headers";

/**
 * Server-side Supabase client. V1 is unauthenticated — we still go through
 * @supabase/ssr so cookie-based auth can drop in later without touching
 * every call site.
 */
export function supabaseServer() {
  const cookieStore = cookies();
  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get: (name) => cookieStore.get(name)?.value,
        set: (name, value, options: CookieOptions) => {
          try { cookieStore.set({ name, value, ...options }); } catch { /* RSC */ }
        },
        remove: (name, options: CookieOptions) => {
          try { cookieStore.set({ name, value: "", ...options }); } catch { /* RSC */ }
        },
      },
    },
  );
}
