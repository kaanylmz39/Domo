export function fmtMoney(n: number | null | undefined, currency = "€"): string {
  if (n == null || isNaN(n as number)) return "—";
  const v = Number(n);
  return `${currency}${v.toLocaleString("nl-NL", { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
}

export function fmtDate(d: string | null | undefined): string {
  if (!d) return "—";
  return new Date(d).toLocaleDateString("nl-NL", { year: "numeric", month: "short", day: "2-digit" });
}

export function fmtMonthLong(month: string): string {
  return new Date(month).toLocaleDateString("en-GB", { year: "numeric", month: "long" });
}

export function startOfMonthISO(d = new Date()): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-01`;
}

export function monthShift(monthISO: string, delta: number): string {
  const [y, m] = monthISO.split("-").map(Number);
  const date = new Date(Date.UTC(y, m - 1 + delta, 1));
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}-01`;
}

export function yearOf(d: string | Date = new Date()): number {
  return new Date(d).getFullYear();
}
