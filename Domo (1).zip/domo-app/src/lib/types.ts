/**
 * Database row types. Hand-rolled to match supabase/migrations/0001_init.sql.
 * In a fuller project you'd generate these with `supabase gen types`.
 */

export type PropertyStatus = "rented" | "empty" | "renovating" | "partly" | "for-sale" | "unavailable";
export type UnitStatus = "rented" | "empty" | "renovating" | "unavailable";
export type ContractStatus = "active" | "ended" | "upcoming";
export type PaidStatus = "expected" | "paid" | "partial" | "unpaid" | "overdue";
export type DepositStatus = "active" | "partially returned" | "returned";

export type ExpenseCategory =
  | "maintenance" | "renovation" | "local tax" | "mortgage" | "insurance"
  | "utilities" | "legal" | "accountant" | "bank" | "management" | "other";

export type DocumentType =
  | "contract" | "invoice" | "bank statement" | "email" | "photo" | "drawing"
  | "tax document" | "valuation document" | "renovation document" | "other";

export type ValuationType =
  | "WOZ" | "official appraisal" | "estimated market value" | "bank valuation" | "other";

export interface Workspace { id: string; name: string; created_at: string; updated_at: string }

export interface UserProfile {
  user_id: string; workspace_id: string;
  full_name: string | null; email: string | null;
  created_at: string; updated_at: string;
}

export interface Property {
  id: string; workspace_id: string; created_by: string | null;
  address: string; city: string; postcode: string | null;
  property_type: "single" | "building";
  status: PropertyStatus;
  purchase_price: number | null; purchase_date: string | null;
  woz_value: number | null; bank: string | null;
  last_renovation: string | null; notes: string | null; hue: number | null;
  created_at: string; updated_at: string;
}

export interface Unit {
  id: string; workspace_id: string; property_id: string;
  label: string; area_m2: number | null; bedrooms: number | null;
  status: UnitStatus; created_at: string; updated_at: string;
}

export interface Tenant {
  id: string; workspace_id: string; name: string;
  email: string | null; phone: string | null; notes: string | null;
  created_at: string; updated_at: string;
}

export interface Contract {
  id: string; workspace_id: string;
  property_id: string; unit_id: string | null; tenant_id: string | null;
  document_id: string | null;
  start_date: string; end_date: string | null;
  monthly_rent: number; due_day: number;
  deposit: number | null; notice_period_months: number | null;
  next_increase_date: string | null;
  notes: string | null; status: ContractStatus;
  created_at: string; updated_at: string;
}

export interface DocumentRow {
  id: string; workspace_id: string;
  property_id: string; unit_id: string | null; tenant_id: string | null;
  contract_id: string | null;
  document_type: DocumentType;
  name: string; original_name: string | null;
  storage_path: string; mime_type: string | null; size_bytes: number | null;
  document_date: string | null; amount: number | null; supplier: string | null;
  notes: string | null; created_by: string | null;
  created_at: string; updated_at: string;
}

export interface Expense {
  id: string; workspace_id: string;
  property_id: string | null; unit_id: string | null; document_id: string | null;
  date: string; category: ExpenseCategory;
  supplier: string | null; amount: number; notes: string | null;
  created_by: string | null;
  created_at: string; updated_at: string;
}

export interface PortfolioExpense {
  id: string; workspace_id: string; document_id: string | null;
  date: string; category: "accountant" | "bank" | "legal" | "management" | "other";
  supplier: string | null; amount: number; notes: string | null;
  created_by: string | null;
  created_at: string; updated_at: string;
}

export interface Income {
  id: string; workspace_id: string;
  property_id: string | null; unit_id: string | null;
  contract_id: string | null; rent_expected_payment_id: string | null;
  date: string; category: "rent" | "other"; amount: number; notes: string | null;
  created_at: string; updated_at: string;
}

export interface Deposit {
  id: string; workspace_id: string;
  property_id: string; unit_id: string | null;
  tenant_id: string | null; contract_id: string | null;
  amount: number; received_date: string; returned_date: string | null;
  status: DepositStatus; notes: string | null;
  created_at: string; updated_at: string;
}

export interface RentExpectedPayment {
  id: string; workspace_id: string; contract_id: string;
  period_month: string; due_date: string;
  expected_amount: number; received_amount: number | null;
  paid_status: PaidStatus; payment_date: string | null;
  note: string | null;
  created_at: string; updated_at: string;
}

export interface Development {
  id: string; workspace_id: string;
  property_id: string; unit_id: string | null;
  title: string; dev_type: string; date: string;
  description: string | null; notes: string | null;
  created_at: string; updated_at: string;
}

export interface Valuation {
  id: string; workspace_id: string; property_id: string; document_id: string | null;
  date: string; amount: number; valuation_type: ValuationType; note: string | null;
  created_at: string; updated_at: string;
}

export interface InboxItem {
  id: string; workspace_id: string; uploaded_by: string | null;
  original_filename: string; storage_path: string;
  mime_type: string | null; size_bytes: number | null;
  ai_status: "pending" | "detecting" | "reviewed" | "approved" | "rejected";
  ai_confidence: number | null;
  suggested_property_id: string | null; suggested_unit_id: string | null;
  suggested_document_type: string | null; suggested_document_date: string | null;
  suggested_amount: number | null; suggested_category: string | null;
  suggested_supplier: string | null; suggested_clean_name: string | null;
  notes: string | null; resulting_document_id: string | null;
  created_at: string; updated_at: string;
}
