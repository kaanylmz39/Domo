import { cache } from "react";
import { supabaseServer } from "@/lib/supabase/server";

/**
 * V1 is single-tenant — no auth. There's one workspace in the database;
 * we look it up and cache it for the request. If you later add auth, swap
 * this for a `user_profiles` lookup keyed by `auth.uid()`.
 */
export const getWorkspace = cache(async (): Promise<{ workspaceId: string; name: string }> => {
  const sb = supabaseServer();
  const { data, error } = await sb
    .from("workspaces")
    .select("id, name")
    .order("created_at", { ascending: true })
    .limit(1)
    .single();
  if (error || !data) {
    throw new Error(
      "No workspace found. Run the SQL migration in supabase/migrations/0001_init.sql against your Supabase project — it seeds a default workspace.",
    );
  }
  return { workspaceId: data.id, name: data.name };
});

/** Convenience for server actions / pages that just want the id. */
export async function requireWorkspace() {
  const { workspaceId } = await getWorkspace();
  return { workspaceId };
}
