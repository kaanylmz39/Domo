"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { supabaseServer } from "@/lib/supabase/server";
import { requireWorkspace } from "@/lib/auth";

/* ============================================================
   PROPERTIES
   ============================================================ */
const PropertySchema = z.object({
  address: z.string().min(1, "Address required"),
  city: z.string().min(1, "City required"),
  postcode: z.string().optional().nullable(),
  property_type: z.enum(["single", "building"]),
  status: z.enum(["rented", "empty", "renovating", "partly", "for-sale", "unavailable"]),
  purchase_price: z.coerce.number().optional().nullable(),
  purchase_date: z.string().optional().nullable(),
  woz_value: z.coerce.number().optional().nullable(),
  bank: z.string().optional().nullable(),
  last_renovation: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
});

function fdToObj(fd: FormData) {
  const o: Record<string, FormDataEntryValue> = {};
  fd.forEach((v, k) => { if (v !== "") o[k] = v; });
  return o;
}

export async function createProperty(fd: FormData) {
  const ctx = await requireWorkspace();
  const data = PropertySchema.parse(fdToObj(fd));
  const sb = supabaseServer();
  const { data: row, error } = await sb.from("properties").insert({
    ...data, workspace_id: ctx.workspaceId,
    hue: Math.floor(Math.random() * 360),
  }).select("id").single();
  if (error) throw new Error(error.message);
  revalidatePath("/portfolio");
  redirect(`/portfolio/${row!.id}`);
}

export async function updateProperty(id: string, fd: FormData) {
  await requireWorkspace();
  const data = PropertySchema.parse(fdToObj(fd));
  const sb = supabaseServer();
  const { error } = await sb.from("properties").update(data).eq("id", id);
  if (error) throw new Error(error.message);
  revalidatePath(`/portfolio/${id}`);
  revalidatePath("/portfolio");
}

export async function deleteProperty(id: string) {
  await requireWorkspace();
  const sb = supabaseServer();
  const { error } = await sb.from("properties").delete().eq("id", id);
  if (error) throw new Error(error.message);
  revalidatePath("/portfolio");
  redirect("/portfolio");
}

/* ============================================================
   UNITS
   ============================================================ */
const UnitSchema = z.object({
  property_id: z.string().uuid(),
  label: z.string().min(1),
  area_m2: z.coerce.number().optional().nullable(),
  bedrooms: z.coerce.number().int().optional().nullable(),
  status: z.enum(["rented", "empty", "renovating", "unavailable"]),
});

export async function createUnit(fd: FormData) {
  const ctx = await requireWorkspace();
  const data = UnitSchema.parse(fdToObj(fd));
  const sb = supabaseServer();
  const { error } = await sb.from("units").insert({ ...data, workspace_id: ctx.workspaceId });
  if (error) throw new Error(error.message);
  revalidatePath(`/portfolio/${data.property_id}`);
}

export async function deleteUnit(id: string, propertyId: string) {
  await requireWorkspace();
  const sb = supabaseServer();
  const { error } = await sb.from("units").delete().eq("id", id);
  if (error) throw new Error(error.message);
  revalidatePath(`/portfolio/${propertyId}`);
}

/* ============================================================
   TENANTS
   ============================================================ */
const TenantSchema = z.object({
  name: z.string().min(1),
  email: z.string().email().optional().or(z.literal("")).nullable(),
  phone: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
});

export async function createTenant(fd: FormData) {
  const ctx = await requireWorkspace();
  const data = TenantSchema.parse(fdToObj(fd));
  const sb = supabaseServer();
  const { error } = await sb.from("tenants").insert({ ...data, workspace_id: ctx.workspaceId });
  if (error) throw new Error(error.message);
  revalidatePath("/portfolio");
}

/* ============================================================
   CONTRACTS
   ============================================================ */
const ContractSchema = z.object({
  property_id: z.string().uuid(),
  unit_id: z.string().uuid().optional().nullable(),
  tenant_id: z.string().uuid().optional().nullable(),
  start_date: z.string(),
  end_date: z.string().optional().nullable(),
  monthly_rent: z.coerce.number().positive(),
  due_day: z.coerce.number().int().min(1).max(31),
  deposit: z.coerce.number().optional().nullable(),
  notice_period_months: z.coerce.number().int().optional().nullable(),
  next_increase_date: z.string().optional().nullable(),
  status: z.enum(["active", "ended", "upcoming"]),
  notes: z.string().optional().nullable(),
});

export async function createContract(fd: FormData) {
  const ctx = await requireWorkspace();
  const data = ContractSchema.parse(fdToObj(fd));
  const sb = supabaseServer();
  const { error } = await sb.from("contracts").insert({ ...data, workspace_id: ctx.workspaceId });
  if (error) throw new Error(error.message);
  revalidatePath(`/portfolio/${data.property_id}`);
  revalidatePath("/rent");
}

export async function deleteContract(id: string, propertyId: string) {
  await requireWorkspace();
  const sb = supabaseServer();
  const { error } = await sb.from("contracts").delete().eq("id", id);
  if (error) throw new Error(error.message);
  revalidatePath(`/portfolio/${propertyId}`);
  revalidatePath("/rent");
}

/* ============================================================
   EXPENSES / INCOME / DEPOSITS
   ============================================================ */
const ExpenseSchema = z.object({
  property_id: z.string().uuid().optional().nullable(),
  unit_id: z.string().uuid().optional().nullable(),
  document_id: z.string().uuid().optional().nullable(),
  date: z.string(),
  category: z.enum([
    "maintenance","renovation","local tax","mortgage","insurance",
    "utilities","legal","accountant","bank","management","other",
  ]),
  supplier: z.string().optional().nullable(),
  amount: z.coerce.number(),
  notes: z.string().optional().nullable(),
});

export async function createExpense(fd: FormData) {
  const ctx = await requireWorkspace();
  const data = ExpenseSchema.parse(fdToObj(fd));
  const sb = supabaseServer();
  const { error } = await sb.from("expenses").insert({
    ...data, workspace_id: ctx.workspaceId,
  });
  if (error) throw new Error(error.message);
  if (data.property_id) revalidatePath(`/portfolio/${data.property_id}`);
  revalidatePath("/");
  revalidatePath("/reports");
}

export async function deleteExpense(id: string, propertyId: string | null) {
  await requireWorkspace();
  const sb = supabaseServer();
  const { error } = await sb.from("expenses").delete().eq("id", id);
  if (error) throw new Error(error.message);
  if (propertyId) revalidatePath(`/portfolio/${propertyId}`);
  revalidatePath("/");
}

const IncomeSchema = z.object({
  property_id: z.string().uuid().optional().nullable(),
  unit_id: z.string().uuid().optional().nullable(),
  contract_id: z.string().uuid().optional().nullable(),
  date: z.string(),
  category: z.enum(["rent", "other"]),
  amount: z.coerce.number(),
  notes: z.string().optional().nullable(),
});

export async function createIncome(fd: FormData) {
  const ctx = await requireWorkspace();
  const data = IncomeSchema.parse(fdToObj(fd));
  const sb = supabaseServer();
  const { error } = await sb.from("income").insert({ ...data, workspace_id: ctx.workspaceId });
  if (error) throw new Error(error.message);
  revalidatePath("/");
  if (data.property_id) revalidatePath(`/portfolio/${data.property_id}`);
}

const DepositSchema = z.object({
  property_id: z.string().uuid(),
  unit_id: z.string().uuid().optional().nullable(),
  tenant_id: z.string().uuid().optional().nullable(),
  contract_id: z.string().uuid().optional().nullable(),
  amount: z.coerce.number(),
  received_date: z.string(),
  returned_date: z.string().optional().nullable(),
  status: z.enum(["active", "partially returned", "returned"]),
  notes: z.string().optional().nullable(),
});

export async function createDeposit(fd: FormData) {
  const ctx = await requireWorkspace();
  const data = DepositSchema.parse(fdToObj(fd));
  const sb = supabaseServer();
  const { error } = await sb.from("deposits").insert({ ...data, workspace_id: ctx.workspaceId });
  if (error) throw new Error(error.message);
  revalidatePath(`/portfolio/${data.property_id}`);
}

/* ============================================================
   DEVELOPMENTS / VALUATIONS
   ============================================================ */
const DevelopmentSchema = z.object({
  property_id: z.string().uuid(),
  unit_id: z.string().uuid().optional().nullable(),
  title: z.string().min(1),
  dev_type: z.string(),
  date: z.string(),
  description: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
});

export async function createDevelopment(fd: FormData) {
  const ctx = await requireWorkspace();
  const data = DevelopmentSchema.parse(fdToObj(fd));
  const sb = supabaseServer();
  const { error } = await sb.from("developments").insert({ ...data, workspace_id: ctx.workspaceId });
  if (error) throw new Error(error.message);
  revalidatePath(`/portfolio/${data.property_id}`);
}

const ValuationSchema = z.object({
  property_id: z.string().uuid(),
  date: z.string(),
  amount: z.coerce.number(),
  valuation_type: z.enum([
    "WOZ","official appraisal","estimated market value","bank valuation","other",
  ]),
  note: z.string().optional().nullable(),
});

export async function createValuation(fd: FormData) {
  const ctx = await requireWorkspace();
  const data = ValuationSchema.parse(fdToObj(fd));
  const sb = supabaseServer();
  const { error } = await sb.from("valuations").insert({ ...data, workspace_id: ctx.workspaceId });
  if (error) throw new Error(error.message);
  revalidatePath(`/portfolio/${data.property_id}`);
}

/* ============================================================
   RENT EXPECTED PAYMENTS — generation + status updates
   ============================================================ */
export async function generateRentForMonth(monthISO: string) {
  const ctx = await requireWorkspace();
  const sb = supabaseServer();
  const { error } = await sb.rpc("generate_rent_for_month", {
    p_month: monthISO, p_workspace: ctx.workspaceId,
  });
  if (error) throw new Error(error.message);
  revalidatePath("/rent");
}

const RentMarkSchema = z.object({
  id: z.string().uuid(),
  paid_status: z.enum(["expected", "paid", "partial", "unpaid", "overdue"]),
  payment_date: z.string().optional().nullable(),
  received_amount: z.coerce.number().optional().nullable(),
  note: z.string().optional().nullable(),
});

export async function markRentPayment(fd: FormData) {
  const ctx = await requireWorkspace();
  const data = RentMarkSchema.parse(fdToObj(fd));
  const sb = supabaseServer();

  const { data: rep, error: e1 } = await sb.from("rent_expected_payments")
    .select("id, expected_amount, contract_id, contracts(property_id, unit_id)")
    .eq("id", data.id).single();
  if (e1 || !rep) throw new Error(e1?.message ?? "Not found");

  const expected = Number(rep.expected_amount);
  let received: number | null = null;
  if (data.paid_status === "paid") {
    received = data.received_amount ?? expected;
  } else if (data.paid_status === "partial") {
    if (data.received_amount == null) throw new Error("Partial requires received amount");
    received = data.received_amount;
  }

  const { error: e2 } = await sb.from("rent_expected_payments").update({
    paid_status: data.paid_status,
    payment_date: data.payment_date ?? null,
    received_amount: received,
    note: data.note ?? null,
  }).eq("id", data.id);
  if (e2) throw new Error(e2.message);

  await sb.from("income").delete().eq("rent_expected_payment_id", data.id);
  if (received && received > 0 && data.payment_date) {
    const contract = (rep as any).contracts;
    await sb.from("income").insert({
      workspace_id: ctx.workspaceId,
      property_id: contract?.property_id,
      unit_id: contract?.unit_id ?? null,
      contract_id: rep.contract_id,
      rent_expected_payment_id: rep.id,
      date: data.payment_date,
      category: "rent",
      amount: received,
    });
  }

  revalidatePath("/rent");
  revalidatePath("/");
}
