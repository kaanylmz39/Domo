"use server";

import { getWorkspace } from "@/lib/auth";

/** Exposed to client components that need to know which workspace to scope
 *  storage uploads under. */
export async function getWorkspaceId(): Promise<string> {
  const { workspaceId } = await getWorkspace();
  return workspaceId;
}
