import { NextRequest, NextResponse } from "next/server";
import { supabaseServer } from "@/lib/supabase/server";
import { requireWorkspace } from "@/lib/auth";

export async function GET(req: NextRequest) {
  await requireWorkspace();
  const sb = supabaseServer();
  const year = Number(new URL(req.url).searchParams.get("year") ?? new Date().getFullYear());
  const yStart = `${year}-01-01`;
  const yEnd = `${year}-12-31`;

  const [{ data: income }, { data: expenses }] = await Promise.all([
    sb.from("income").select("date, category, amount, properties(address)").gte("date", yStart).lte("date", yEnd),
    sb.from("expenses").select("date, category, supplier, amount, properties(address)").gte("date", yStart).lte("date", yEnd),
  ]);

  const lines = ["type,date,category,supplier,property,amount"];
  (income ?? []).forEach((r: any) =>
    lines.push(`income,${r.date},${r.category},,${r.properties?.address ?? ""},${r.amount}`));
  (expenses ?? []).forEach((r: any) =>
    lines.push(`expense,${r.date},${r.category},${r.supplier ?? ""},${r.properties?.address ?? ""},${r.amount}`));

  return new NextResponse(lines.join("\n"), {
    headers: {
      "Content-Type": "text/csv",
      "Content-Disposition": `attachment; filename="domo-${year}.csv"`,
    },
  });
}
