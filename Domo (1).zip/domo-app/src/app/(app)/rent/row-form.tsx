"use client";

import { Modal } from "@/components/ui";
import { markRentPayment } from "@/app/actions/domain";
import { useState } from "react";

export function RentRowForm({ row }: { row: any }) {
  const today = new Date().toISOString().slice(0, 10);
  const [status, setStatus] = useState<string>(row.paid_status ?? "expected");

  return (
    <Modal title="Log payment" trigger={<button className="btn">Log</button>}>
      {(close) => (
        <form action={markRentPayment} className="space-y-3">
          <input type="hidden" name="id" value={row.id} />
          <div className="text-sm text-muted">
            Expected <span className="num text-ink">€{Number(row.expected_amount).toLocaleString("nl-NL")}</span> from {row.contracts?.tenants?.name ?? "tenant"}.
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="label">Status</label>
              <select name="paid_status" className="input" value={status}
                      onChange={(e) => setStatus(e.target.value)}>
                <option value="expected">Expected</option>
                <option value="paid">Paid</option>
                <option value="partial">Partially paid</option>
                <option value="unpaid">Unpaid</option>
                <option value="overdue">Overdue</option>
              </select>
            </div>
            <div><label className="label">Payment date</label>
              <input name="payment_date" type="date" className="input"
                     defaultValue={row.payment_date ?? today} />
            </div>
            {status === "partial" && (
              <div className="col-span-2">
                <label className="label">Received amount (required)</label>
                <input name="received_amount" type="number" step="0.01" required className="input"
                       defaultValue={row.received_amount ?? ""} />
              </div>
            )}
            {status === "paid" && (
              <div className="col-span-2">
                <label className="label">Received amount (defaults to expected)</label>
                <input name="received_amount" type="number" step="0.01" className="input"
                       placeholder={row.expected_amount} />
              </div>
            )}
            <div className="col-span-2"><label className="label">Note</label>
              <input name="note" className="input" defaultValue={row.note ?? ""} /></div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" className="btn" onClick={close}>Cancel</button>
            <button type="submit" className="btn btn-primary">Save</button>
          </div>
        </form>
      )}
    </Modal>
  );
}
