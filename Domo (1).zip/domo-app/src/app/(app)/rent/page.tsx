import { requireWorkspace } from "@/lib/auth";
import { supabaseServer } from "@/lib/supabase/server";
import { fmtDate, fmtMoney, fmtMonthLong, monthShift, startOfMonthISO } from "@/lib/format";
import { Badge } from "@/components/ui";
import Link from "next/link";
import { generateRentForMonth } from "@/app/actions/domain";
import { RentRowForm } from "./row-form";

export const dynamic = "force-dynamic";

const STATUS_TONE: Record<string, "ok" | "warn" | "danger" | "muted"> = {
  paid: "ok", partial: "warn", unpaid: "warn", overdue: "danger", expected: "muted",
};

export default async function RentPage({ searchParams }: { searchParams: { month?: string } }) {
  const ctx = await requireWorkspace();
  const monthISO = searchParams.month ?? startOfMonthISO();
  const sb = supabaseServer();

  // Always (idempotently) ensure rows exist for the selected month.
  await sb.rpc("generate_rent_for_month", { p_month: monthISO, p_workspace: ctx.workspaceId });

  const { data: rows } = await sb.from("rent_expected_payments")
    .select(`id, period_month, due_date, expected_amount, received_amount, paid_status, payment_date, note,
             contract_id, contracts(monthly_rent, property_id, unit_id, tenants(name), units(label), properties(address, city))`)
    .eq("period_month", monthISO)
    .order("due_date");

  const tally = { expected: 0, received: 0, unpaid: 0 };
  (rows ?? []).forEach((r: any) => {
    tally.expected += Number(r.expected_amount);
    tally.received += Number(r.received_amount ?? 0);
    if (r.paid_status === "unpaid" || r.paid_status === "overdue" || r.paid_status === "partial") {
      tally.unpaid += Math.max(0, Number(r.expected_amount) - Number(r.received_amount ?? 0));
    }
  });

  return (
    <div className="px-10 py-8">
      <div className="flex items-end justify-between mb-6">
        <div>
          <h1 className="text-[22px] font-semibold tracking-tight">Huurcontrole</h1>
          <p className="text-sm text-muted">Expected rent for {fmtMonthLong(monthISO)}</p>
        </div>
        <nav className="flex gap-1">
          <Link className="btn" href={`/rent?month=${monthShift(monthISO, -1)}`}>← Prev</Link>
          <Link className="btn" href={`/rent?month=${startOfMonthISO()}`}>Today</Link>
          <Link className="btn" href={`/rent?month=${monthShift(monthISO, 1)}`}>Next →</Link>
        </nav>
      </div>

      <div className="grid md:grid-cols-3 gap-3 mb-6">
        <Stat label="Expected" value={fmtMoney(tally.expected)} />
        <Stat label="Received" value={fmtMoney(tally.received)} />
        <Stat label="Unpaid" value={fmtMoney(tally.unpaid)} tone={tally.unpaid > 0 ? "warn" : "ok"} />
      </div>

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-[11px] uppercase tracking-wider text-muted border-b border-line">
              <th className="px-4 py-2 font-medium">Property</th>
              <th className="px-4 py-2 font-medium">Unit</th>
              <th className="px-4 py-2 font-medium">Tenant</th>
              <th className="px-4 py-2 font-medium text-right">Expected</th>
              <th className="px-4 py-2 font-medium text-right">Received</th>
              <th className="px-4 py-2 font-medium">Due</th>
              <th className="px-4 py-2 font-medium">Status</th>
              <th className="px-4 py-2 font-medium">Paid on</th>
              <th className="px-4 py-2 font-medium" />
            </tr>
          </thead>
          <tbody>
            {(rows ?? []).map((r: any) => (
              <tr key={r.id} className="border-b border-line last:border-0 align-middle">
                <td className="px-4 py-2.5">{r.contracts?.properties?.address}</td>
                <td className="px-4 py-2.5 text-muted">{r.contracts?.units?.label ?? "—"}</td>
                <td className="px-4 py-2.5">{r.contracts?.tenants?.name ?? "—"}</td>
                <td className="px-4 py-2.5 text-right num">{fmtMoney(r.expected_amount)}</td>
                <td className="px-4 py-2.5 text-right num">{r.received_amount ? fmtMoney(r.received_amount) : "—"}</td>
                <td className="px-4 py-2.5 num">{fmtDate(r.due_date)}</td>
                <td className="px-4 py-2.5"><Badge tone={STATUS_TONE[r.paid_status]}>{r.paid_status}</Badge></td>
                <td className="px-4 py-2.5 num text-muted">{fmtDate(r.payment_date)}</td>
                <td className="px-4 py-2.5 text-right">
                  <RentRowForm row={r} />
                </td>
              </tr>
            ))}
            {(!rows || rows.length === 0) && (
              <tr><td colSpan={9} className="px-4 py-10 text-center text-muted text-sm">
                No active contracts cover this month. Add a contract from a property's Contracts tab.
              </td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Stat({ label, value, tone }:
  { label: string; value: string; tone?: "ok" | "warn" }) {
  const c = tone === "warn" ? "text-[color:var(--warn)]"
          : tone === "ok"   ? "text-[color:var(--accent)]" : "text-ink";
  return (
    <div className="card p-4">
      <div className="label">{label}</div>
      <div className={`text-2xl font-semibold num mt-1 ${c}`}>{value}</div>
    </div>
  );
}
