import Link from "next/link";
import { requireWorkspace } from "@/lib/auth";
import { supabaseServer } from "@/lib/supabase/server";
import { fmtMoney, yearOf } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function ReportsPage() {
  await requireWorkspace();
  const sb = supabaseServer();
  const year = yearOf();
  const yStart = `${year}-01-01`;
  const yEnd = `${year}-12-31`;

  const [{ data: income }, { data: expenses }, { data: unpaid }, { data: valuations }] = await Promise.all([
    sb.from("income").select("amount, category").gte("date", yStart).lte("date", yEnd),
    sb.from("expenses").select("amount, category").gte("date", yStart).lte("date", yEnd),
    sb.from("rent_expected_payments")
      .select("expected_amount, received_amount, paid_status, contracts(properties(address))")
      .in("paid_status", ["unpaid","overdue","partial"]),
    sb.from("valuations").select("amount, valuation_type, date, properties(address)")
      .order("date", { ascending: false }).limit(50),
  ]);

  const totalIncome = (income ?? []).reduce((a: number, r: any) => a + Number(r.amount), 0);
  const totalExpenses = (expenses ?? []).reduce((a: number, r: any) => a + Number(r.amount), 0);
  const byCat = (rows: any[] | null) => {
    const m: Record<string, number> = {};
    (rows ?? []).forEach((r: any) => { m[r.category] = (m[r.category] ?? 0) + Number(r.amount); });
    return Object.entries(m).sort((a, b) => b[1] - a[1]);
  };

  return (
    <div className="px-10 py-8 max-w-6xl">
      <div className="mb-7">
        <h1 className="text-[22px] font-semibold tracking-tight">Reports</h1>
        <p className="text-sm text-muted">Year {year}</p>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <ReportCard
          title="Tax report"
          subtitle="Year totals — income, expenses, result"
          rows={[
            ["Total income", fmtMoney(totalIncome)],
            ["Total expenses", fmtMoney(totalExpenses)],
            ["Result", fmtMoney(totalIncome - totalExpenses)],
          ]}
          csvHref={`/api/export/yearly?year=${year}`}
        />

        <ReportCard
          title="Expenses by category"
          rows={byCat(expenses).map(([k, v]) => [k, fmtMoney(v)])}
        />
        <ReportCard
          title="Income by category"
          rows={byCat(income).map(([k, v]) => [k, fmtMoney(v)])}
        />

        <ReportCard
          title="Unpaid rent"
          rows={(unpaid ?? []).map((r: any) => [
            r.contracts?.properties?.address ?? "—",
            fmtMoney(Math.max(0, Number(r.expected_amount) - Number(r.received_amount ?? 0))),
          ])}
          empty="No unpaid rent."
        />

        <ReportCard
          title="Valuation overview"
          rows={(valuations ?? []).map((v: any) => [
            `${v.properties?.address ?? "—"} (${v.valuation_type})`,
            fmtMoney(v.amount),
          ])}
          empty="No valuations recorded."
        />
      </div>

      <p className="text-xs text-muted mt-6">
        PDF generation and advanced reports can be added later. CSV exports use the same workspace-scoped data.
      </p>
    </div>
  );
}

function ReportCard({
  title, subtitle, rows, csvHref, empty,
}: { title: string; subtitle?: string; rows: any[][]; csvHref?: string; empty?: string }) {
  return (
    <div className="card p-4">
      <div className="flex items-center justify-between mb-2">
        <div>
          <h2 className="font-semibold text-[15px]">{title}</h2>
          {subtitle && <p className="text-xs text-muted">{subtitle}</p>}
        </div>
        {csvHref && <Link href={csvHref} className="btn">Export CSV</Link>}
      </div>
      {rows.length === 0 ? (
        <div className="text-sm text-muted py-2">{empty ?? "Nothing yet."}</div>
      ) : (
        <table className="w-full text-sm">
          <tbody>
            {rows.map(([k, v], i) => (
              <tr key={i} className="border-b border-line last:border-0">
                <td className="py-1.5 capitalize">{k}</td>
                <td className="py-1.5 text-right num">{v}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
