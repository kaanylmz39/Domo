"use client";

import { useTransition } from "react";
import { fmtDate, fmtMoney } from "@/lib/format";
import { ConfirmButton } from "@/components/ConfirmButton";
import { deleteDocument, signedDocumentUrl } from "@/app/actions/documents";

export function DocumentRow({ doc, propertyId }: { doc: any; propertyId: string }) {
  const [, start] = useTransition();
  function openSigned() {
    start(async () => {
      const url = await signedDocumentUrl(doc.storage_path);
      window.open(url, "_blank", "noopener");
    });
  }
  return (
    <tr className="border-b border-line last:border-0">
      <td className="px-4 py-2.5">
        <button onClick={openSigned} className="text-ink hover:underline text-left">
          {doc.name}
        </button>
        {doc.original_name && doc.original_name !== doc.name && (
          <div className="text-[11px] text-muted">orig: {doc.original_name}</div>
        )}
      </td>
      <td className="px-4 py-2.5 text-muted num">{fmtDate(doc.document_date)}</td>
      <td className="px-4 py-2.5 text-muted">{doc.supplier ?? "—"}</td>
      <td className="px-4 py-2.5 text-right num">{doc.amount ? fmtMoney(doc.amount) : "—"}</td>
      <td className="px-4 py-2.5 text-right">
        <ConfirmButton
          action={deleteDocument.bind(null, doc.id, propertyId, doc.storage_path)}
          title="Delete this document?"
          description="Are you sure? The file will be removed from storage too."
          confirmLabel="Delete document"
          trigger={<button className="text-muted hover:text-[color:var(--danger)] text-xs">Delete</button>}
        />
      </td>
    </tr>
  );
}
