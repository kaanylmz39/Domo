"use client";

import { Modal } from "@/components/ui";
import { createExpense } from "@/app/actions/domain";

const CATS = ["maintenance","renovation","local tax","mortgage","insurance","utilities","legal","accountant","bank","management","other"];

export function NewExpenseButton({ propertyId, units }: { propertyId: string; units: any[] }) {
  return (
    <Modal title="New expense" trigger={<button className="btn btn-primary">+ New expense</button>}>
      {(close) => (
        <form action={createExpense} className="space-y-3">
          <input type="hidden" name="property_id" value={propertyId} />
          <div className="grid grid-cols-2 gap-3">
            <div><label className="label">Date</label><input name="date" type="date" required className="input" /></div>
            <div><label className="label">Category</label>
              <select name="category" className="input">{CATS.map(c => <option key={c}>{c}</option>)}</select></div>
            <div><label className="label">Supplier</label><input name="supplier" className="input" /></div>
            <div><label className="label">Amount</label><input name="amount" type="number" step="0.01" required className="input" /></div>
            <div className="col-span-2"><label className="label">Unit (optional)</label>
              <select name="unit_id" className="input"><option value="">—</option>
                {units.map(u => <option key={u.id} value={u.id}>{u.label}</option>)}
              </select></div>
            <div className="col-span-2"><label className="label">Notes</label><textarea name="notes" rows={2} className="input" /></div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" className="btn" onClick={close}>Cancel</button>
            <button type="submit" className="btn btn-primary">Create expense</button>
          </div>
        </form>
      )}
    </Modal>
  );
}
