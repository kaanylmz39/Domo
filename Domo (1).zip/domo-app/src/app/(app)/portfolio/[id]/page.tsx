import Link from "next/link";
import { notFound } from "next/navigation";
import { requireWorkspace } from "@/lib/auth";
import { supabaseServer } from "@/lib/supabase/server";
import { Badge } from "@/components/ui";
import { fmtMoney, fmtDate } from "@/lib/format";
import { ConfirmButton } from "@/components/ConfirmButton";
import { deleteProperty } from "@/app/actions/domain";

import { OverviewTab, UnitsTab, ContractsTab, DevelopmentsTab, ValuationsTab } from "./client-tabs";
import { PropertyFinancialsTab } from "./financials-tab";
import { PropertyDocumentsTab } from "./documents-tab";
import { PropertyWarningsTab } from "./warnings-tab";

export const dynamic = "force-dynamic";

const TABS = ["overview","units","financials","contracts","documents","developments","valuations","warnings"] as const;

export default async function PropertyDetail({
  params, searchParams,
}: { params: { id: string }; searchParams: { tab?: string } }) {
  await requireWorkspace();
  const sb = supabaseServer();
  const tab = (TABS as readonly string[]).includes(searchParams.tab ?? "") ? (searchParams.tab as string) : "overview";

  const { data: property } = await sb.from("properties").select("*").eq("id", params.id).single();
  if (!property) notFound();

  const [{ data: units }, { data: contracts }, { data: tenants }] = await Promise.all([
    sb.from("units").select("*").eq("property_id", params.id).order("label"),
    sb.from("contracts").select("*, tenants(name), units(label)").eq("property_id", params.id).order("start_date", { ascending: false }),
    sb.from("tenants").select("*").order("name"),
  ]);

  return (
    <div className="px-10 py-8 max-w-6xl">
      <Link href="/portfolio" className="text-sm text-muted hover:text-ink">← Portfolio</Link>
      <div className="flex items-start justify-between mt-2 mb-6 gap-6">
        <div>
          <div className="flex items-center gap-3">
            <span className="inline-block w-3 h-9 rounded-sm"
                  style={{ background: `oklch(70% 0.08 ${property.hue ?? 90})` }} />
            <h1 className="text-[22px] font-semibold tracking-tight">{property.address}</h1>
            <Badge>{property.status.replace("-", " ")}</Badge>
          </div>
          <div className="text-sm text-muted mt-1">{property.city} {property.postcode ?? ""} · {property.property_type}</div>
        </div>
        <ConfirmButton
          action={deleteProperty.bind(null, property.id)}
          title="Delete this property?"
          description="Are you sure you want to delete this property? This action cannot be undone."
          confirmLabel="Delete property"
          trigger={<button className="btn">Delete</button>}
        />
      </div>

      <nav className="border-b border-line flex gap-1 mb-6 text-sm overflow-x-auto">
        {TABS.map(t => (
          <Link key={t} href={`/portfolio/${property.id}?tab=${t}`}
                className={`px-3 py-2 -mb-px border-b-2 ${tab === t ? "border-ink font-medium" : "border-transparent text-muted hover:text-ink"}`}>
            {t[0].toUpperCase() + t.slice(1)}
          </Link>
        ))}
      </nav>

      {tab === "overview" && (
        <OverviewTab property={property} units={units ?? []} contracts={contracts ?? []} />
      )}
      {tab === "units" && (
        <UnitsTab property={property} units={units ?? []} />
      )}
      {tab === "financials" && (
        await PropertyFinancialsTab({ propertyId: property.id, units: units ?? [] })
      )}
      {tab === "contracts" && (
        <ContractsTab property={property} units={units ?? []} contracts={contracts ?? []} tenants={tenants ?? []} />
      )}
      {tab === "documents" && (
        await PropertyDocumentsTab({ propertyId: property.id, units: units ?? [], contracts: contracts ?? [] })
      )}
      {tab === "developments" && (
        <DevelopmentsTab property={property} units={units ?? []} />
      )}
      {tab === "valuations" && (
        <ValuationsTab property={property} />
      )}
      {tab === "warnings" && (
        await PropertyWarningsTab({ propertyId: property.id })
      )}

      <div className="mt-10 grid md:grid-cols-3 gap-3 text-sm">
        <Meta label="Purchase price" value={fmtMoney(property.purchase_price)} />
        <Meta label="Purchase date" value={fmtDate(property.purchase_date)} />
        <Meta label="WOZ value" value={fmtMoney(property.woz_value)} />
        <Meta label="Bank / mortgage" value={property.bank || "—"} />
        <Meta label="Last renovation" value={fmtDate(property.last_renovation)} />
        <Meta label="Notes" value={property.notes || "—"} />
      </div>
    </div>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div className="card p-3">
      <div className="label">{label}</div>
      <div className="text-sm mt-0.5">{value}</div>
    </div>
  );
}
