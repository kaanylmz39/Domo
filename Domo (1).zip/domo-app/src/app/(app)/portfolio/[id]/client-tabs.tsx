"use client";

import { Badge, Modal } from "@/components/ui";
import { ConfirmButton } from "@/components/ConfirmButton";
import { fmtDate, fmtMoney } from "@/lib/format";
import {
  createUnit, deleteUnit, createContract, deleteContract,
  createDevelopment, createValuation,
} from "@/app/actions/domain";

/* ---------- OVERVIEW ---------- */
export function OverviewTab({ property, units, contracts }: { property: any; units: any[]; contracts: any[] }) {
  const active = contracts.filter(c => c.status === "active");
  const monthlyRent = active.reduce((a, c) => a + Number(c.monthly_rent || 0), 0);
  return (
    <div className="grid md:grid-cols-3 gap-3">
      <Stat label="Units" value={String(units.length || 1)} />
      <Stat label="Active contracts" value={String(active.length)} />
      <Stat label="Monthly rent" value={fmtMoney(monthlyRent)} />
    </div>
  );
}
function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="card p-4">
      <div className="label">{label}</div>
      <div className="text-2xl font-semibold num mt-1">{value}</div>
    </div>
  );
}

/* ---------- UNITS ---------- */
export function UnitsTab({ property, units }: { property: any; units: any[] }) {
  return (
    <div>
      <div className="flex justify-end mb-3">
        <Modal title="Add unit" trigger={<button className="btn btn-primary">+ Add unit</button>}>
          {(close) => (
            <form action={createUnit} className="space-y-3">
              <input type="hidden" name="property_id" value={property.id} />
              <div className="grid grid-cols-2 gap-3">
                <div><label className="label">Label</label><input name="label" className="input" required /></div>
                <div><label className="label">Status</label>
                  <select name="status" className="input" defaultValue="empty">
                    <option value="rented">Rented</option><option value="empty">Empty</option>
                    <option value="renovating">Renovating</option><option value="unavailable">Unavailable</option>
                  </select></div>
                <div><label className="label">Area (m²)</label><input name="area_m2" type="number" step="0.1" className="input" /></div>
                <div><label className="label">Bedrooms</label><input name="bedrooms" type="number" className="input" /></div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" className="btn" onClick={close}>Cancel</button>
                <button type="submit" className="btn btn-primary">Add unit</button>
              </div>
            </form>
          )}
        </Modal>
      </div>
      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-[11px] uppercase tracking-wider text-muted border-b border-line">
              <th className="px-4 py-2 font-medium">Label</th><th className="px-4 py-2 font-medium">Status</th>
              <th className="px-4 py-2 font-medium text-right">Area</th><th className="px-4 py-2 font-medium text-right">Bedrooms</th>
              <th className="px-4 py-2 w-10" />
            </tr>
          </thead>
          <tbody>
            {units.map(u => (
              <tr key={u.id} className="border-b border-line last:border-0">
                <td className="px-4 py-2.5 font-medium">{u.label}</td>
                <td className="px-4 py-2.5"><Badge tone={u.status === "rented" ? "ok" : "muted"}>{u.status}</Badge></td>
                <td className="px-4 py-2.5 text-right num">{u.area_m2 ?? "—"}</td>
                <td className="px-4 py-2.5 text-right num">{u.bedrooms ?? "—"}</td>
                <td className="px-4 py-2.5">
                  <ConfirmButton action={deleteUnit.bind(null, u.id, property.id)}
                    title="Delete this unit?" description="Are you sure? This action cannot be undone."
                    confirmLabel="Delete unit"
                    trigger={<button className="text-muted hover:text-[color:var(--danger)] text-xs">Delete</button>} />
                </td>
              </tr>
            ))}
            {units.length === 0 && <tr><td colSpan={5} className="px-4 py-8 text-center text-muted text-sm">No units yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ---------- CONTRACTS ---------- */
export function ContractsTab({
  property, units, contracts, tenants,
}: { property: any; units: any[]; contracts: any[]; tenants: any[] }) {
  return (
    <div>
      <div className="flex justify-end mb-3">
        <Modal title="New contract" trigger={<button className="btn btn-primary">+ New contract</button>}>
          {(close) => (
            <form action={createContract} className="space-y-3">
              <input type="hidden" name="property_id" value={property.id} />
              <div className="grid grid-cols-2 gap-3">
                <div><label className="label">Unit</label>
                  <select name="unit_id" className="input"><option value="">—</option>
                    {units.map(u => <option key={u.id} value={u.id}>{u.label}</option>)}
                  </select></div>
                <div><label className="label">Tenant</label>
                  <select name="tenant_id" className="input"><option value="">—</option>
                    {tenants.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                  </select></div>
                <div><label className="label">Start date</label><input name="start_date" type="date" required className="input" /></div>
                <div><label className="label">End date</label><input name="end_date" type="date" className="input" /></div>
                <div><label className="label">Monthly rent</label><input name="monthly_rent" type="number" step="0.01" required className="input" /></div>
                <div><label className="label">Due day</label><input name="due_day" type="number" min={1} max={31} defaultValue={1} required className="input" /></div>
                <div><label className="label">Deposit</label><input name="deposit" type="number" step="0.01" className="input" /></div>
                <div><label className="label">Notice (months)</label><input name="notice_period_months" type="number" defaultValue={1} className="input" /></div>
                <div><label className="label">Next increase</label><input name="next_increase_date" type="date" className="input" /></div>
                <div><label className="label">Status</label>
                  <select name="status" className="input" defaultValue="active">
                    <option value="active">Active</option><option value="upcoming">Upcoming</option><option value="ended">Ended</option>
                  </select></div>
                <div className="col-span-2"><label className="label">Notes</label><textarea name="notes" rows={2} className="input" /></div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" className="btn" onClick={close}>Cancel</button>
                <button type="submit" className="btn btn-primary">Create contract</button>
              </div>
            </form>
          )}
        </Modal>
      </div>
      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-[11px] uppercase tracking-wider text-muted border-b border-line">
              <th className="px-4 py-2 font-medium">Tenant</th><th className="px-4 py-2 font-medium">Unit</th>
              <th className="px-4 py-2 font-medium">Period</th><th className="px-4 py-2 font-medium text-right">Monthly</th>
              <th className="px-4 py-2 font-medium">Status</th><th className="px-4 py-2 w-10" />
            </tr>
          </thead>
          <tbody>
            {contracts.map((c: any) => (
              <tr key={c.id} className="border-b border-line last:border-0">
                <td className="px-4 py-2.5">{c.tenants?.name ?? "—"}</td>
                <td className="px-4 py-2.5 text-muted">{c.units?.label ?? "—"}</td>
                <td className="px-4 py-2.5 text-muted">{fmtDate(c.start_date)} → {c.end_date ? fmtDate(c.end_date) : "open"}</td>
                <td className="px-4 py-2.5 text-right num">{fmtMoney(c.monthly_rent)}</td>
                <td className="px-4 py-2.5"><Badge tone={c.status === "active" ? "ok" : "muted"}>{c.status}</Badge></td>
                <td className="px-4 py-2.5">
                  <ConfirmButton action={deleteContract.bind(null, c.id, property.id)}
                    title="Delete this contract?" description="Are you sure? This action cannot be undone."
                    confirmLabel="Delete contract"
                    trigger={<button className="text-muted hover:text-[color:var(--danger)] text-xs">Delete</button>} />
                </td>
              </tr>
            ))}
            {contracts.length === 0 && <tr><td colSpan={6} className="px-4 py-8 text-center text-muted text-sm">No contracts yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ---------- DEVELOPMENTS ---------- */
export function DevelopmentsTab({ property, units }: { property: any; units: any[] }) {
  return (
    <div className="space-y-3">
      <div className="flex justify-end">
        <Modal title="New development" trigger={<button className="btn btn-primary">+ New development</button>}>
          {(close) => (
            <form action={createDevelopment} className="space-y-3">
              <input type="hidden" name="property_id" value={property.id} />
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2"><label className="label">Title</label><input name="title" required className="input" /></div>
                <div><label className="label">Type</label>
                  <select name="dev_type" className="input">
                    <option>renovation</option><option>maintenance</option><option>extension</option>
                    <option>new bathroom</option><option>new kitchen</option><option>roof repair</option>
                    <option>permit</option><option>other</option>
                  </select></div>
                <div><label className="label">Date</label><input name="date" type="date" required className="input" /></div>
                <div className="col-span-2"><label className="label">Description</label><textarea name="description" rows={3} className="input" /></div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" className="btn" onClick={close}>Cancel</button>
                <button type="submit" className="btn btn-primary">Create</button>
              </div>
            </form>
          )}
        </Modal>
      </div>
      <div className="card p-6 text-center text-sm text-muted">
        Refresh after creating to see entries here. (A dedicated developments list table can be added if you want it surfaced.)
      </div>
    </div>
  );
}

/* ---------- VALUATIONS ---------- */
export function ValuationsTab({ property }: { property: any }) {
  return (
    <div className="space-y-3">
      <div className="flex justify-end">
        <Modal title="New valuation" trigger={<button className="btn btn-primary">+ New valuation</button>}>
          {(close) => (
            <form action={createValuation} className="space-y-3">
              <input type="hidden" name="property_id" value={property.id} />
              <div className="grid grid-cols-2 gap-3">
                <div><label className="label">Date</label><input name="date" type="date" required className="input" /></div>
                <div><label className="label">Amount</label><input name="amount" type="number" step="0.01" required className="input" /></div>
                <div className="col-span-2"><label className="label">Type</label>
                  <select name="valuation_type" className="input">
                    <option>WOZ</option><option>official appraisal</option>
                    <option>estimated market value</option><option>bank valuation</option><option>other</option>
                  </select></div>
                <div className="col-span-2"><label className="label">Note</label><textarea name="note" rows={2} className="input" /></div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" className="btn" onClick={close}>Cancel</button>
                <button type="submit" className="btn btn-primary">Create</button>
              </div>
            </form>
          )}
        </Modal>
      </div>
      <div className="card p-6 text-center text-sm text-muted">
        Refresh after creating to see entries here.
      </div>
    </div>
  );
}
