import { supabaseServer } from "@/lib/supabase/server";
import { fmtDate, fmtMoney } from "@/lib/format";
import { DocumentRow } from "./documents-row";
import { UploadDocumentButton } from "./upload-document";

const CATEGORIES = [
  ["contract","Contracts"], ["invoice","Invoices"], ["bank statement","Bank Statements"],
  ["tax document","Tax Documents"], ["photo","Photos"], ["drawing","Drawings"],
  ["renovation document","Renovation"], ["valuation document","Valuations"], ["other","Other"],
];

export async function PropertyDocumentsTab({ propertyId, units, contracts }: { propertyId: string; units: any[]; contracts: any[] }) {
  const sb = supabaseServer();
  const { data: docs } = await sb.from("documents")
    .select("*").eq("property_id", propertyId).order("created_at", { ascending: false });

  const byCat: Record<string, any[]> = {};
  (docs ?? []).forEach((d: any) => { (byCat[d.document_type] ??= []).push(d); });

  return (
    <div className="space-y-6">
      <div className="flex justify-end">
        <UploadDocumentButton propertyId={propertyId} units={units} contracts={contracts} />
      </div>
      {CATEGORIES.map(([key, label]) => {
        const list = byCat[key] ?? [];
        if (list.length === 0) return null;
        return (
          <section key={key}>
            <h3 className="text-[13px] font-semibold text-muted uppercase tracking-wider mb-2">{label}</h3>
            <div className="card overflow-hidden">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-[11px] uppercase tracking-wider text-muted border-b border-line">
                    <th className="px-4 py-2 font-medium">Name</th>
                    <th className="px-4 py-2 font-medium">Date</th>
                    <th className="px-4 py-2 font-medium">Supplier</th>
                    <th className="px-4 py-2 font-medium text-right">Amount</th>
                    <th className="px-4 py-2 w-20" />
                  </tr>
                </thead>
                <tbody>
                  {list.map((d: any) => <DocumentRow key={d.id} doc={d} propertyId={propertyId} />)}
                </tbody>
              </table>
            </div>
          </section>
        );
      })}
      {(!docs || docs.length === 0) && (
        <div className="card p-8 text-center text-muted text-sm">
          No documents yet. Upload one above.
        </div>
      )}
    </div>
  );
}
