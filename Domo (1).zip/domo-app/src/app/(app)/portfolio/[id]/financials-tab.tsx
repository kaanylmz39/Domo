import { supabaseServer } from "@/lib/supabase/server";
import { fmtDate, fmtMoney } from "@/lib/format";
import { Badge } from "@/components/ui";
import { ConfirmButton } from "@/components/ConfirmButton";
import { deleteExpense } from "@/app/actions/domain";
import { NewExpenseButton } from "./financials-new";

export async function PropertyFinancialsTab({ propertyId, units }: { propertyId: string; units: any[] }) {
  const sb = supabaseServer();
  const [{ data: expenses }, { data: income }] = await Promise.all([
    sb.from("expenses").select("*").eq("property_id", propertyId).order("date", { ascending: false }),
    sb.from("income").select("*").eq("property_id", propertyId).order("date", { ascending: false }).limit(50),
  ]);
  const expSum = (expenses ?? []).reduce((a: number, r: any) => a + Number(r.amount), 0);
  const incSum = (income ?? []).reduce((a: number, r: any) => a + Number(r.amount), 0);

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-3 gap-3">
        <div className="card p-4"><div className="label">Total income</div><div className="text-xl num font-semibold mt-1">{fmtMoney(incSum)}</div></div>
        <div className="card p-4"><div className="label">Total expenses</div><div className="text-xl num font-semibold mt-1">{fmtMoney(expSum)}</div></div>
        <div className="card p-4"><div className="label">Net</div><div className="text-xl num font-semibold mt-1">{fmtMoney(incSum - expSum)}</div></div>
      </div>

      <section>
        <div className="flex items-center justify-between mb-2">
          <h2 className="font-semibold text-[15px]">Expenses</h2>
          <NewExpenseButton propertyId={propertyId} units={units} />
        </div>
        <div className="card overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[11px] uppercase tracking-wider text-muted border-b border-line">
                <th className="px-4 py-2 font-medium">Date</th><th className="px-4 py-2 font-medium">Category</th>
                <th className="px-4 py-2 font-medium">Supplier</th><th className="px-4 py-2 font-medium text-right">Amount</th>
                <th className="px-4 py-2 w-10" />
              </tr>
            </thead>
            <tbody>
              {(expenses ?? []).map((e: any) => (
                <tr key={e.id} className="border-b border-line last:border-0">
                  <td className="px-4 py-2 num">{fmtDate(e.date)}</td>
                  <td className="px-4 py-2"><Badge tone="muted">{e.category}</Badge></td>
                  <td className="px-4 py-2 text-muted">{e.supplier ?? "—"}</td>
                  <td className="px-4 py-2 text-right num">{fmtMoney(e.amount)}</td>
                  <td className="px-4 py-2">
                    <ConfirmButton
                      action={deleteExpense.bind(null, e.id, propertyId)}
                      title="Delete this expense?"
                      description="Are you sure? This action cannot be undone."
                      confirmLabel="Delete expense"
                      trigger={<button className="text-muted hover:text-[color:var(--danger)] text-xs">Delete</button>}
                    />
                  </td>
                </tr>
              ))}
              {(expenses ?? []).length === 0 && (
                <tr><td colSpan={5} className="px-4 py-8 text-center text-muted text-sm">No expenses yet.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      <section>
        <h2 className="font-semibold text-[15px] mb-2">Income (recent)</h2>
        <div className="card overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[11px] uppercase tracking-wider text-muted border-b border-line">
                <th className="px-4 py-2 font-medium">Date</th><th className="px-4 py-2 font-medium">Category</th>
                <th className="px-4 py-2 font-medium text-right">Amount</th><th className="px-4 py-2">Notes</th>
              </tr>
            </thead>
            <tbody>
              {(income ?? []).map((i: any) => (
                <tr key={i.id} className="border-b border-line last:border-0">
                  <td className="px-4 py-2 num">{fmtDate(i.date)}</td>
                  <td className="px-4 py-2"><Badge>{i.category}</Badge></td>
                  <td className="px-4 py-2 text-right num">{fmtMoney(i.amount)}</td>
                  <td className="px-4 py-2 text-muted">{i.notes ?? "—"}</td>
                </tr>
              ))}
              {(income ?? []).length === 0 && (
                <tr><td colSpan={4} className="px-4 py-8 text-center text-muted text-sm">
                  No income yet. Log payments in Huurcontrole to populate this list.
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
