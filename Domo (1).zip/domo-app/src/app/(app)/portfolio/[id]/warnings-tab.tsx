import { supabaseServer } from "@/lib/supabase/server";
import { fmtDate, fmtMoney } from "@/lib/format";

/**
 * V1 warning logic — straightforward checks:
 *  • Any contract ending within 60 days
 *  • Any rent expected payment in unpaid/overdue/partial
 *  • Rent increase due within 60 days
 */
export async function PropertyWarningsTab({ propertyId }: { propertyId: string }) {
  const sb = supabaseServer();
  const today = new Date();
  const soon = new Date(today.getTime() + 60 * 86400 * 1000).toISOString().slice(0, 10);

  const [{ data: endingSoon }, { data: unpaid }, { data: increaseSoon }] = await Promise.all([
    sb.from("contracts").select("id, end_date, tenants(name)")
      .eq("property_id", propertyId).eq("status", "active")
      .not("end_date", "is", null).lte("end_date", soon),
    sb.from("rent_expected_payments")
      .select("id, period_month, due_date, expected_amount, received_amount, paid_status, contracts!inner(property_id, tenants(name))")
      .eq("contracts.property_id", propertyId)
      .in("paid_status", ["unpaid", "overdue", "partial"]),
    sb.from("contracts").select("id, next_increase_date, tenants(name)")
      .eq("property_id", propertyId).eq("status", "active")
      .not("next_increase_date", "is", null).lte("next_increase_date", soon),
  ]);

  const warnings = [
    ...(endingSoon ?? []).map((c: any) => ({
      kind: "Contract ending",
      detail: `${c.tenants?.name ?? "Tenant"} — ends ${fmtDate(c.end_date)}`,
      tone: "warn" as const,
    })),
    ...(unpaid ?? []).map((p: any) => ({
      kind: p.paid_status === "overdue" ? "Overdue rent" : "Unpaid rent",
      detail: `${p.contracts?.tenants?.name ?? "Tenant"} — ${fmtMoney(p.expected_amount)} due ${fmtDate(p.due_date)}`,
      tone: p.paid_status === "overdue" ? "danger" as const : "warn" as const,
    })),
    ...(increaseSoon ?? []).map((c: any) => ({
      kind: "Rent increase possible",
      detail: `${c.tenants?.name ?? "Tenant"} — ${fmtDate(c.next_increase_date)}`,
      tone: "default" as const,
    })),
  ];

  if (warnings.length === 0) {
    return <div className="card p-8 text-center text-muted text-sm">No warnings for this property.</div>;
  }
  return (
    <div className="card overflow-hidden">
      <ul className="divide-y divide-line">
        {warnings.map((w, i) => (
          <li key={i} className="px-4 py-3 flex items-center justify-between">
            <div>
              <div className="font-medium text-sm">{w.kind}</div>
              <div className="text-sm text-muted">{w.detail}</div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
