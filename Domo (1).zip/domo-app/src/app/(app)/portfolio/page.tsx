import Link from "next/link";
import { requireWorkspace } from "@/lib/auth";
import { supabaseServer } from "@/lib/supabase/server";
import { Badge } from "@/components/ui";
import { NewPropertyButton } from "./new-property";

export const dynamic = "force-dynamic";

const STATUS_TONE: Record<string, "ok" | "warn" | "muted" | "default" | "danger"> = {
  rented: "ok", "partly": "warn", empty: "muted",
  renovating: "warn", "for-sale": "default", unavailable: "danger",
};

export default async function PortfolioPage({ searchParams }: { searchParams: { q?: string } }) {
  await requireWorkspace();
  const sb = supabaseServer();
  const q = (searchParams.q ?? "").trim();

  let query = sb.from("properties")
    .select("id, address, city, postcode, status, property_type, purchase_price, woz_value, hue")
    .order("city").order("address");
  if (q) query = query.or(`address.ilike.%${q}%,city.ilike.%${q}%,postcode.ilike.%${q}%`);
  const { data: properties } = await query;

  // Unit counts per property
  const ids = (properties ?? []).map(p => p.id);
  const { data: units } = ids.length
    ? await sb.from("units").select("property_id, status").in("property_id", ids)
    : { data: [] as any[] };
  const unitsBy: Record<string, { total: number; rented: number }> = {};
  (units ?? []).forEach((u: any) => {
    const b = unitsBy[u.property_id] ??= { total: 0, rented: 0 };
    b.total++; if (u.status === "rented") b.rented++;
  });

  return (
    <div className="px-10 py-8">
      <div className="flex items-end justify-between mb-6">
        <div>
          <h1 className="text-[22px] font-semibold tracking-tight">Portfolio</h1>
          <p className="text-sm text-muted">{properties?.length ?? 0} properties</p>
        </div>
        <div className="flex gap-2 items-center">
          <form>
            <input name="q" defaultValue={q} placeholder="Search address, city…" className="input w-64" />
          </form>
          <NewPropertyButton />
        </div>
      </div>

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-[11px] uppercase tracking-wider text-muted border-b border-line">
              <th className="px-4 py-2 font-medium">Address</th>
              <th className="px-4 py-2 font-medium">City</th>
              <th className="px-4 py-2 font-medium">Type</th>
              <th className="px-4 py-2 font-medium">Status</th>
              <th className="px-4 py-2 font-medium text-right">Units</th>
              <th className="px-4 py-2 font-medium text-right">Purchase</th>
              <th className="px-4 py-2 font-medium text-right">WOZ</th>
            </tr>
          </thead>
          <tbody>
            {(properties ?? []).map(p => (
              <tr key={p.id} className="border-b border-line last:border-0 hover:bg-[oklch(98%_0.005_95)]">
                <td className="px-4 py-2.5">
                  <Link href={`/portfolio/${p.id}`} className="flex items-center gap-2">
                    <span className="inline-block w-2 h-7 rounded-sm"
                          style={{ background: `oklch(70% 0.08 ${p.hue ?? 90})` }} />
                    <span className="font-medium">{p.address}</span>
                  </Link>
                </td>
                <td className="px-4 py-2.5 text-muted">{p.city} {p.postcode}</td>
                <td className="px-4 py-2.5 text-muted capitalize">{p.property_type}</td>
                <td className="px-4 py-2.5">
                  <Badge tone={STATUS_TONE[p.status] ?? "muted"}>{p.status.replace("-", " ")}</Badge>
                </td>
                <td className="px-4 py-2.5 text-right num text-muted">
                  {unitsBy[p.id] ? `${unitsBy[p.id].rented}/${unitsBy[p.id].total}` : "—"}
                </td>
                <td className="px-4 py-2.5 text-right num">
                  {p.purchase_price ? `€${Number(p.purchase_price).toLocaleString("nl-NL")}` : "—"}
                </td>
                <td className="px-4 py-2.5 text-right num text-muted">
                  {p.woz_value ? `€${Number(p.woz_value).toLocaleString("nl-NL")}` : "—"}
                </td>
              </tr>
            ))}
            {(!properties || properties.length === 0) && (
              <tr><td colSpan={7} className="px-4 py-10 text-center text-muted text-sm">
                No properties yet. Click <em>New property</em> to add the first one.
              </td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
