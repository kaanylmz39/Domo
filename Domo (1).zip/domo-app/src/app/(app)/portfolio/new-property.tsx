"use client";

import { Modal } from "@/components/ui";
import { createProperty } from "@/app/actions/domain";

export function NewPropertyButton() {
  return (
    <Modal title="New property"
      trigger={<button className="btn btn-primary">+ New property</button>}>
      {(close) => (
        <form action={createProperty} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label">Address</label>
              <input name="address" required className="input" />
            </div>
            <div>
              <label className="label">City</label>
              <input name="city" required className="input" />
            </div>
            <div>
              <label className="label">Postcode</label>
              <input name="postcode" className="input" />
            </div>
            <div>
              <label className="label">Type</label>
              <select name="property_type" className="input" defaultValue="single">
                <option value="single">Single (one unit)</option>
                <option value="building">Building (multiple units)</option>
              </select>
            </div>
            <div>
              <label className="label">Status</label>
              <select name="status" className="input" defaultValue="empty">
                <option value="rented">Rented</option>
                <option value="empty">Empty</option>
                <option value="partly">Partly rented</option>
                <option value="renovating">Renovating</option>
                <option value="for-sale">For sale</option>
                <option value="unavailable">Unavailable</option>
              </select>
            </div>
            <div>
              <label className="label">Purchase price</label>
              <input name="purchase_price" type="number" step="0.01" className="input" />
            </div>
            <div>
              <label className="label">Purchase date</label>
              <input name="purchase_date" type="date" className="input" />
            </div>
            <div>
              <label className="label">WOZ value</label>
              <input name="woz_value" type="number" step="0.01" className="input" />
            </div>
            <div className="col-span-2">
              <label className="label">Bank / mortgage</label>
              <input name="bank" className="input" />
            </div>
            <div className="col-span-2">
              <label className="label">Notes</label>
              <textarea name="notes" rows={2} className="input" />
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" className="btn" onClick={close}>Cancel</button>
            <button type="submit" className="btn btn-primary">Create property</button>
          </div>
        </form>
      )}
    </Modal>
  );
}
