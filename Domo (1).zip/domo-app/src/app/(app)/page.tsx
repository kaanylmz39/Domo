import Link from "next/link";
import { requireWorkspace } from "@/lib/auth";
import { supabaseServer } from "@/lib/supabase/server";
import { fmtMoney, yearOf } from "@/lib/format";

export default async function CockpitPage() {
  await requireWorkspace();
  const sb = supabaseServer();
  const year = yearOf();
  const yearStart = `${year}-01-01`;
  const yearEnd = `${year}-12-31`;
  const monthStart = `${year}-${String(new Date().getMonth() + 1).padStart(2, "0")}-01`;

  const [
    { data: incomeMonth },
    { data: incomeYear },
    { data: expensesYear },
    { data: unpaid },
    { data: propertyCount },
  ] = await Promise.all([
    sb.from("income").select("amount").gte("date", monthStart).lte("date", yearEnd),
    sb.from("income").select("amount").gte("date", yearStart).lte("date", yearEnd),
    sb.from("expenses").select("amount").gte("date", yearStart).lte("date", yearEnd),
    sb.from("rent_expected_payments").select("expected_amount, received_amount")
      .in("paid_status", ["unpaid", "overdue", "partial"]),
    sb.from("properties").select("id", { count: "exact", head: true }),
  ]);

  const sum = (rows: { amount?: number; expected_amount?: number; received_amount?: number | null }[] | null, key: string) =>
    (rows ?? []).reduce((a, r: any) => a + Number(r[key] ?? 0), 0);

  const monthlyIncome = sum(incomeMonth, "amount");
  const yearlyIncome = sum(incomeYear, "amount");
  const yearlyExpenses = sum(expensesYear, "amount");
  const yearlyResult = yearlyIncome - yearlyExpenses;
  const unpaidAmount = (unpaid ?? []).reduce((a: number, r: any) =>
    a + Math.max(0, Number(r.expected_amount) - Number(r.received_amount ?? 0)), 0);

  return (
    <div className="px-10 py-8 max-w-6xl">
      <div className="flex items-end justify-between mb-7">
        <div>
          <h1 className="text-[22px] font-semibold tracking-tight">Cockpit</h1>
          <p className="text-sm text-muted">Your portfolio at a glance — {year}</p>
        </div>
        <div className="text-sm text-muted">{(propertyCount as any)?.count ?? 0} properties</div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <Card label={`${new Date().toLocaleDateString("en", { month: "long" })} income`} value={fmtMoney(monthlyIncome)} />
        <Card label="Yearly income" value={fmtMoney(yearlyIncome)} />
        <Card label="Yearly expenses" value={fmtMoney(yearlyExpenses)} />
        <Card label="Yearly result" value={fmtMoney(yearlyResult)}
              tone={yearlyResult >= 0 ? "ok" : "danger"} />
        <Card label="Unpaid rent" value={fmtMoney(unpaidAmount)}
              tone={unpaidAmount > 0 ? "warn" : "ok"} link="/rent" />
      </div>

      <div className="mt-10 grid md:grid-cols-2 gap-4">
        <div className="card p-5">
          <h2 className="font-semibold mb-2 text-[15px]">Quick links</h2>
          <ul className="text-sm space-y-1.5">
            <li><Link className="text-ink hover:underline" href="/portfolio">View portfolio →</Link></li>
            <li><Link className="text-ink hover:underline" href="/rent">Open Huurcontrole →</Link></li>
            <li><Link className="text-ink hover:underline" href="/inbox">Review AI Inbox →</Link></li>
          </ul>
        </div>
        <div className="card p-5">
          <h2 className="font-semibold mb-2 text-[15px]">Reminder</h2>
          <p className="text-sm text-muted">
            Deposits are tracked separately and never counted as income or in your yearly result.
          </p>
        </div>
      </div>
    </div>
  );
}

function Card({ label, value, tone, link }:
  { label: string; value: string; tone?: "ok" | "warn" | "danger"; link?: string }) {
  const toneColor = tone === "warn" ? "text-[color:var(--warn)]"
                   : tone === "danger" ? "text-[color:var(--danger)]"
                   : tone === "ok" ? "text-[color:var(--accent)]" : "text-ink";
  const body = (
    <div className="card p-4 h-full">
      <div className="label">{label}</div>
      <div className={`text-2xl font-semibold num mt-1 ${toneColor}`}>{value}</div>
    </div>
  );
  return link ? <Link href={link}>{body}</Link> : body;
}
