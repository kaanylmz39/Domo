import { requireWorkspace } from "@/lib/auth";
import { supabaseServer } from "@/lib/supabase/server";
import { fmtDate, fmtMoney } from "@/lib/format";
import { Badge } from "@/components/ui";
import { InboxReviewForm } from "./review-form";
import { UploadInboxButton } from "./upload";

export const dynamic = "force-dynamic";

export default async function InboxPage() {
  await requireWorkspace();
  const sb = supabaseServer();
  const [{ data: items }, { data: properties }, { data: units }] = await Promise.all([
    sb.from("inbox_items").select("*, properties:suggested_property_id(address)")
      .neq("ai_status", "approved").order("created_at", { ascending: false }),
    sb.from("properties").select("id, address, city").order("city").order("address"),
    sb.from("units").select("id, property_id, label").order("label"),
  ]);

  return (
    <div className="px-10 py-8">
      <div className="flex items-end justify-between mb-6">
        <div>
          <h1 className="text-[22px] font-semibold tracking-tight">AI Inbox</h1>
          <p className="text-sm text-muted">Review and approve uploaded files before they're filed.</p>
        </div>
        <UploadInboxButton />
      </div>

      <div className="space-y-3">
        {(items ?? []).map((it: any) => (
          <InboxReviewForm
            key={it.id}
            item={it}
            properties={properties ?? []}
            units={units ?? []}
          />
        ))}
        {(!items || items.length === 0) && (
          <div className="card p-8 text-center text-muted text-sm">
            Inbox is empty. Upload a file to start the review flow.
          </div>
        )}
      </div>
    </div>
  );
}
