"use client";

import { useRef, useState } from "react";
import { ConfirmButton } from "@/components/ConfirmButton";
import { saveInboxReview, approveInboxItem, deleteInboxItem } from "@/app/actions/documents";

const DOC_TYPES = ["contract","invoice","bank statement","email","photo","drawing","tax document","valuation document","renovation document","other"];
const EXP_CATS = ["maintenance","renovation","local tax","mortgage","insurance","utilities","legal","accountant","bank","management","other"];

export function InboxReviewForm({ item, properties, units }: { item: any; properties: any[]; units: any[] }) {
  const [propId, setPropId] = useState<string>(item.suggested_property_id ?? "");
  const [approveOpen, setApproveOpen] = useState(false);
  const formRef = useRef<HTMLFormElement>(null);
  const propUnits = units.filter(u => u.property_id === propId);

  return (
    <div className="card p-4">
      <div className="flex items-start justify-between mb-3">
        <div>
          <div className="font-medium text-sm">{item.original_filename}</div>
          <div className="text-[11px] text-muted">
            uploaded {new Date(item.created_at).toLocaleString("nl-NL")} · status {item.ai_status}
          </div>
        </div>
        <ConfirmButton
          action={deleteInboxItem.bind(null, item.id, item.storage_path)}
          title="Delete this inbox item?"
          description="Are you sure? The file will be removed."
          confirmLabel="Delete"
          trigger={<button className="text-muted hover:text-[color:var(--danger)] text-xs">Delete</button>}
        />
      </div>

      <form ref={formRef} className="grid grid-cols-2 gap-3" action={approveInboxItem}>
        <input type="hidden" name="id" value={item.id} />
        <div>
          <label className="label">Property *</label>
          <select name="suggested_property_id" className="input" value={propId}
                  onChange={(e) => setPropId(e.target.value)}>
            <option value="">— Select property —</option>
            {properties.map(p => <option key={p.id} value={p.id}>{p.address}, {p.city}</option>)}
          </select>
        </div>
        <div>
          <label className="label">Unit</label>
          <select name="suggested_unit_id" className="input" defaultValue={item.suggested_unit_id ?? ""}>
            <option value="">—</option>
            {propUnits.map(u => <option key={u.id} value={u.id}>{u.label}</option>)}
          </select>
        </div>
        <div>
          <label className="label">Document type *</label>
          <select name="suggested_document_type" className="input"
                  defaultValue={item.suggested_document_type ?? "invoice"}>
            {DOC_TYPES.map(t => <option key={t}>{t}</option>)}
          </select>
        </div>
        <div>
          <label className="label">Date</label>
          <input name="suggested_document_date" type="date" className="input"
                 defaultValue={item.suggested_document_date ?? ""} />
        </div>
        <div>
          <label className="label">Amount</label>
          <input name="suggested_amount" type="number" step="0.01" className="input"
                 defaultValue={item.suggested_amount ?? ""} />
        </div>
        <div>
          <label className="label">Expense category</label>
          <select name="suggested_category" className="input" defaultValue={item.suggested_category ?? ""}>
            <option value="">—</option>
            {EXP_CATS.map(c => <option key={c}>{c}</option>)}
          </select>
        </div>
        <div>
          <label className="label">Supplier</label>
          <input name="suggested_supplier" className="input" defaultValue={item.suggested_supplier ?? ""} />
        </div>
        <div>
          <label className="label">Clean filename</label>
          <input name="suggested_clean_name" className="input"
                 defaultValue={item.suggested_clean_name ?? item.original_filename} />
        </div>
        <div className="col-span-2">
          <label className="label">Notes</label>
          <input name="notes" className="input" defaultValue={item.notes ?? ""} />
        </div>
        <div className="col-span-2 flex items-center justify-end gap-2 pt-1">
          <button type="submit" formAction={saveInboxReview} className="btn">Save draft</button>
          <button type="button" className="btn btn-primary" onClick={() => setApproveOpen(true)}>
            Approve & file
          </button>
        </div>
      </form>

      {approveOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center"
             style={{ background: "rgba(20,20,20,0.4)" }}
             onClick={() => setApproveOpen(false)}>
          <div className="card p-6 max-w-md w-full mx-4 shadow-xl"
               onClick={(e) => e.stopPropagation()}>
            <h2 className="font-semibold mb-2">Approve and file this item?</h2>
            <p className="text-sm text-muted mb-5">
              Are you sure? The file will be renamed and moved into the property folder.
              If amount and category are set, an expense will also be created.
            </p>
            <div className="flex justify-end gap-2">
              <button type="button" className="btn" onClick={() => setApproveOpen(false)}>Cancel</button>
              <button type="button" className="btn btn-primary"
                      onClick={() => { setApproveOpen(false); formRef.current?.requestSubmit(); }}>
                Approve
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
