"use client";

import { useState, useTransition } from "react";
import { Modal } from "@/components/ui";
import { supabaseBrowser } from "@/lib/supabase/browser";
import { getWorkspaceId } from "@/app/actions/workspace";

export function UploadInboxButton() {
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  return (
    <Modal title="Upload to inbox" trigger={<button className="btn btn-primary">+ Upload</button>}>
      {(close) => (
        <form
          className="space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            if (!file) { setError("Choose a file"); return; }
            start(async () => {
              setError(null);
              const sb = supabaseBrowser();
              const workspaceId = await getWorkspaceId();
              const cleanName = file.name.replace(/[^a-zA-Z0-9._-]+/g, "_");
              const path = `${workspaceId}/_inbox/${Date.now()}_${cleanName}`;
              const { error: upErr } = await sb.storage.from("documents").upload(path, file, {
                contentType: file.type, upsert: false,
              });
              if (upErr) return setError(upErr.message);
              const { error: insErr } = await sb.from("inbox_items").insert({
                workspace_id: workspaceId,
                original_filename: file.name,
                storage_path: path,
                mime_type: file.type,
                size_bytes: file.size,
                ai_status: "pending",
                suggested_clean_name: file.name,
              });
              if (insErr) return setError(insErr.message);
              window.location.reload();
            });
          }}
        >
          <input type="file" required onChange={(e) => setFile(e.target.files?.[0] ?? null)} className="input" />
          {error && <div className="text-sm text-[color:var(--danger)]">{error}</div>}
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" className="btn" onClick={close}>Cancel</button>
            <button type="submit" className="btn btn-primary" disabled={pending}>
              {pending ? "Uploading…" : "Upload"}
            </button>
          </div>
        </form>
      )}
    </Modal>
  );
}
