"use client";

import { useState } from "react";
import { useFormStatus } from "react-dom";

/**
 * Wraps a destructive action in a centered confirmation modal.
 * Usage:
 *   <ConfirmButton action={deleteProperty.bind(null, id)}
 *                  title="Delete this property?"
 *                  description="…"
 *                  confirmLabel="Delete property" />
 */
export function ConfirmButton({
  action,
  title,
  description,
  confirmLabel,
  trigger,
  danger = true,
}: {
  action: () => Promise<void> | void;
  title: string;
  description: string;
  confirmLabel: string;
  trigger: React.ReactNode;
  danger?: boolean;
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <span onClick={() => setOpen(true)} role="button" tabIndex={0}
            onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") setOpen(true); }}>
        {trigger}
      </span>
      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center"
             style={{ background: "rgba(20,20,20,0.4)" }}
             onClick={() => setOpen(false)}>
          <div className="card max-w-md w-full mx-4 p-6 shadow-xl"
               onClick={(e) => e.stopPropagation()}>
            <h2 className="text-base font-semibold mb-2">{title}</h2>
            <p className="text-sm text-muted mb-5">{description}</p>
            <form action={action} className="flex justify-end gap-2">
              <button type="button" className="btn" onClick={() => setOpen(false)}>
                Cancel
              </button>
              <ConfirmSubmit label={confirmLabel} danger={danger} />
            </form>
          </div>
        </div>
      )}
    </>
  );
}

function ConfirmSubmit({ label, danger }: { label: string; danger: boolean }) {
  const { pending } = useFormStatus();
  return (
    <button type="submit"
            className={`btn ${danger ? "btn-danger" : "btn-primary"}`}
            disabled={pending}>
      {pending ? "Working…" : label}
    </button>
  );
}
