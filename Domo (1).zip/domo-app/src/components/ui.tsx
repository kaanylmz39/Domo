"use client";

import { useState } from "react";

export function Modal({
  title, children, trigger,
}: { title: string; children: (close: () => void) => React.ReactNode; trigger: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <span onClick={() => setOpen(true)} role="button" tabIndex={0}
            onKeyDown={(e) => { if (e.key === "Enter") setOpen(true); }}>
        {trigger}
      </span>
      {open && (
        <div className="fixed inset-0 z-40 flex items-start justify-center pt-24"
             style={{ background: "rgba(20,20,20,0.4)" }}
             onClick={() => setOpen(false)}>
          <div className="card max-w-lg w-full mx-4 p-6 shadow-xl"
               onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base font-semibold">{title}</h2>
              <button className="text-muted text-sm" onClick={() => setOpen(false)}>✕</button>
            </div>
            {children(() => setOpen(false))}
          </div>
        </div>
      )}
    </>
  );
}

export function Badge({ children, tone = "default" }:
  { children: React.ReactNode; tone?: "default" | "ok" | "warn" | "danger" | "muted" }) {
  const map: Record<string, string> = {
    default: "bg-[color:var(--accent-soft)] text-[color:var(--accent)]",
    ok:      "bg-[color:var(--accent-soft)] text-[color:var(--accent)]",
    warn:    "bg-[oklch(96%_0.07_75)] text-[color:var(--warn)]",
    danger:  "bg-[oklch(95%_0.05_27)] text-[color:var(--danger)]",
    muted:   "bg-[oklch(95%_0_0)] text-[color:var(--muted)]",
  };
  return (
    <span className={`inline-flex items-center px-2 py-[2px] rounded text-[11px] font-medium ${map[tone]}`}>
      {children}
    </span>
  );
}
