# Domo — Real estate cockpit (Next.js + Supabase MVP, no login)

A small online real-estate data manager for tiny portfolios. Property is the
central anchor; tenants, contracts, rent, expenses, documents, deposits,
developments and valuations all hang off it.

**This is the single-tenant V1: no login, one shared workspace.** Drop the
SQL migration into Supabase, set two env vars, deploy to Vercel — done.

---

## Tech

- **Next.js 14** (App Router) + React + TypeScript
- **Tailwind CSS**
- **Supabase** — Postgres + Storage (Auth is NOT used in V1)
- **Vercel** — deployment target

---

## Architecture overview

```
src/
  app/
    (app)/                         all pages — no auth gate
      layout.tsx                   sidebar shell
      page.tsx                     Cockpit
      portfolio/                   Portfolio list + /[id] property dossier
      rent/                        Huurcontrole monthly checklist
      inbox/                       AI Inbox review/approve
      reports/                     Yearly totals + CSV export
      settings/                    Workspace + category info
    api/export/yearly/route.ts     CSV stream
    actions/
      domain.ts                    'use server' CRUD for everything
      documents.ts                 documents + inbox approval flow
      workspace.ts                 exposes the workspace id to client
  lib/
    supabase/{browser,server}.ts   anon-key clients (no auth)
    auth.ts                        getWorkspace() — looks up the single workspace
    format.ts                      money/date helpers
    types.ts                       hand-rolled DB row types
  components/
    ConfirmButton.tsx              destructive-action confirm modal
    ui.tsx                         Modal, Badge
supabase/
  migrations/0001_init.sql         schema, RLS disabled, storage bucket, RPC, seed
```

### Workspace model (V1)

- The migration **seeds one workspace row** in the `workspaces` table.
- `getWorkspace()` (`src/lib/auth.ts`) does `select * from workspaces limit 1`
  and React-caches the result for the request.
- Every domain row carries `workspace_id`, so when you later turn auth back on
  you only need to tweak `getWorkspace()` to look up by user — no app changes.

### Why no RLS in V1?

RLS is **disabled** on every table and the storage bucket policies are
permissive. This is intentional for the no-login MVP — the anon key is doing
all reads and writes. When you add login, re-enable RLS and add
`workspace_id = current_workspace_id()` policies (the pattern is left as
inline comments in the migration).

> ⚠️ Anyone with your Supabase URL + anon key can read/write your data.
> Treat them like a password — only ship the app to URLs you control, and
> consider IP-allowlisting the Supabase project if it goes public.

### Property is the anchor

All domain rows carry `property_id` directly or transitively. Documents are
categorized by `document_type` (contract, invoice, …) and rendered in the
property dossier under fixed buckets.

### Rent control flow

1. Active contracts have `monthly_rent` + `due_day`.
2. `generate_rent_for_month(p_month, p_workspace)` (Postgres function)
   idempotently inserts one `rent_expected_payments` row per active contract
   per month.
3. The Huurcontrole page calls that function on every visit, then lists rows.
4. User clicks "Log" → server action `markRentPayment` updates status and
   syncs an `income` row (rent only — deposits are NEVER income).
5. Cockpit + Reports aggregate from `income` and `expenses`.

### AI Inbox flow (V1 — no real AI yet)

1. Upload writes to `documents` bucket at `<workspace_id>/_inbox/...`.
2. Row appears in `inbox_items` with `ai_status='pending'`.
3. User reviews/edits property, unit, type, date, amount, category, clean
   filename.
4. "Approve & file" requires confirmation. On approve:
   - file is moved to `<workspace_id>/<property_id>/<timestamped clean name>`
   - a `documents` row is created
   - if amount + category are set, an `expenses` row is auto-created
   - inbox item is marked approved + linked to the document
5. `suggested_*` columns are already on `inbox_items` so a real classifier
   can populate them later; the UI doesn't change.

### Destructive actions

Every destructive or major action goes through `<ConfirmButton>` (a centered
Cancel / [Action] modal): delete property, unit, contract, document,
expense, inbox item; approve inbox item.

---

## Database schema

See `supabase/migrations/0001_init.sql`. Tables:

`workspaces, properties, units, tenants, contracts, documents, expenses,
portfolio_expenses, income, deposits, rent_expected_payments, developments,
development_documents, valuations, inbox_items`.

---

## Local development

### Prerequisites

- Node 20+
- A Supabase project (free tier is fine — https://supabase.com)

### Setup

```bash
cd domo-app
npm install
cp .env.example .env.local
# edit .env.local with your Supabase URL + anon key
```

In the Supabase dashboard:

1. **SQL Editor → New query** → paste `supabase/migrations/0001_init.sql` → Run.
2. **Storage** — confirm the `documents` bucket exists (the migration creates it).

That's it. No auth setup required.

### Run

```bash
npm run dev
```

Open http://localhost:3000 — you should land directly on the Cockpit.

---

## Deployment

### Push to GitHub

```bash
cd domo-app
git init
git add .
git commit -m "Domo MVP"
git branch -M main
git remote add origin git@github.com:<you>/<repo>.git
git push -u origin main
```

### Deploy to Vercel

1. Go to https://vercel.com → **Add New… → Project** → import your repo.
2. **Root Directory** → `domo-app`.
3. **Environment Variables**:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
4. Click **Deploy**.

No other Vercel configuration is needed — Next.js 14 is auto-detected.

### Required environment variables

| Variable | Notes |
|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | from Supabase project settings → API |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | from Supabase project settings → API |

---

## What V1 deliberately does NOT include

(Per the spec — easy to add later because the schema already names the fields)

- Login / signup / multi-user (single shared workspace for now)
- Real AI classification of inbox items
- Tenant portal / online rent collection
- Bank or payment integrations
- PDF reports

### Where to add things later

| Want to add | Where |
|---|---|
| Login + per-user workspaces | re-enable RLS in the migration, restore the `user_profiles` table + auth trigger, rewrite `getWorkspace()` to look up by `auth.uid()` |
| Real AI for inbox | `inbox_items.suggested_*` fields already exist — fill them from a server action or edge function on upload |
| New expense category | Update the CHECK constraint in the migration + `EXP_CATS` arrays in `actions/domain.ts` + `inbox/review-form.tsx` + `settings/page.tsx` |
| New document type | Same — update CHECK + `DOC_TYPES` arrays |
| Custom report | Drop a new page under `(app)/reports/` — read from existing tables |
